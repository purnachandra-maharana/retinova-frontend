import { useEffect, useMemo, useState } from "react";

function ClinicalReport({ caseData, review, onBack, onDashboard }) {
  const item = caseData || {};
  const decision = review?.decision || "Not recorded";
  const notes = review?.notes || "No clinical notes recorded.";
  const reviewedAt = review?.reviewedAt || new Date().toLocaleString("en-IN", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit"
  });

  const [imageUrl, setImageUrl] = useState("");
  useEffect(() => {
    if (!item.imageFile) {
      setImageUrl(item.imageUrl || "");
      return;
    }
    const url = URL.createObjectURL(item.imageFile);
    setImageUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [item.imageFile, item.imageUrl]);

  const reportId = useMemo(() => `RPT-${item.id || "CASE"}`, [item.id]);
  const referral = decision === "Refer for ophthalmic care";

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 print:bg-white">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-slate-200 print:static">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 h-[76px] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button type="button" onClick={onBack} className="no-print w-11 h-11 rounded-2xl border border-slate-200 bg-white font-bold text-lg hover:bg-slate-50 transition">←</button>
            <div className="w-11 h-11 rounded-2xl bg-[#071b20] text-white flex items-center justify-center font-bold">RS</div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">RetinaSafe</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">Clinical report</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-400">Report ID</p>
            <p className="font-bold text-slate-800">{reportId}</p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-5 sm:px-8 py-8 print:px-0 print:py-0">
        <div className="flex flex-wrap gap-3 justify-end mb-5 no-print">
          <button type="button" onClick={() => window.print()} className="px-5 py-3 rounded-xl border border-slate-200 bg-white font-bold hover:bg-slate-50 transition">🖨 Print / Save PDF</button>
          <button type="button" onClick={onDashboard} className="px-5 py-3 rounded-xl bg-[#071b20] text-white font-bold hover:bg-teal-700 transition">Back to dashboard</button>
        </div>

        <article className="bg-white rounded-[30px] shadow-sm border border-slate-200 overflow-hidden print:rounded-none print:border-0 print:shadow-none">
          <section className="p-7 md:p-10 border-b border-slate-100">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
              <div>
                <p className="text-[10px] uppercase tracking-[0.24em] text-teal-600 font-bold">Final clinical screening report</p>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight mt-2">Diabetic Retinopathy Screening</h2>
                <p className="text-sm text-slate-500 mt-2">AI-assisted screening with ophthalmologist review</p>
              </div>
              <div className={`rounded-2xl px-5 py-4 border ${referral ? "bg-rose-50 border-rose-200" : "bg-emerald-50 border-emerald-200"}`}>
                <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Final decision</p>
                <p className={`font-bold mt-1 ${referral ? "text-rose-700" : "text-emerald-700"}`}>{decision}</p>
              </div>
            </div>
          </section>

          <section className="p-7 md:p-10 border-b border-slate-100">
            <SectionTitle eyebrow="01 · Patient" title="Patient & screening details" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              <Detail label="Patient name" value={item.patient} />
              <Detail label="Case ID" value={item.id} />
              <Detail label="Age / Sex" value={`${item.age || "—"} years · ${item.sex || "—"}`} />
              <Detail label="Screened eye" value={item.eye} />
              <Detail label="PHC / Clinic" value={item.clinic} />
              <Detail label="Screening date" value={item.date} />
            </div>
          </section>

          <section className="p-7 md:p-10 border-b border-slate-100">
            <SectionTitle eyebrow="02 · AI" title="AI assessment" />
            <div className="mt-6 rounded-2xl bg-[#071b20] text-white p-6">
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-widest text-teal-300 font-bold">Classification</p>
                  <p className="text-2xl font-bold mt-1">{item.result || "Not supplied"}</p>
                </div>
                <p className="text-3xl font-bold">{item.confidence ?? "—"}%</p>
              </div>
              <div className="h-2 rounded-full bg-white/10 mt-5 overflow-hidden">
                <div className="h-full rounded-full bg-teal-400" style={{ width: `${Math.max(0, Math.min(100, Number(item.confidence) || 0))}%` }} />
              </div>
              <p className="text-xs text-slate-400 mt-3">AI output is screening support and must be interpreted with clinical evidence.</p>
            </div>
          </section>

          <section className="p-7 md:p-10 border-b border-slate-100 page-break-before">
            <SectionTitle eyebrow="03 · Evidence" title="Retinal evidence & explainability" />
            <div className="grid lg:grid-cols-2 gap-5 mt-6">
              <EvidencePanel title="Original fundus image" src={imageUrl} empty="Fundus image will appear here when supplied by the screening pipeline." />
              <EvidencePanel title="Grad-CAM explanation" src={item.gradCamUrl} empty="Grad-CAM output will appear here when supplied by MATLAB." />
            </div>
          </section>

          <section className="p-7 md:p-10 border-b border-slate-100">
            <SectionTitle eyebrow="04 · Clinical review" title="Findings & reviewer decision" />
            <div className="grid lg:grid-cols-2 gap-5 mt-6">
              <div className="rounded-2xl border border-slate-200 p-5">
                <p className="font-bold">Clinical findings</p>
                <div className="mt-4 space-y-3">
                  {(item.findings || defaultFindings(item.quality)).map((finding) => (
                    <div key={finding.title} className="flex items-start justify-between gap-4 py-3 border-b last:border-0 border-slate-100">
                      <div><p className="text-sm font-semibold">{finding.title}</p><p className="text-xs text-slate-500 mt-1">{finding.detail}</p></div>
                      <span className="text-xs font-bold text-slate-700 whitespace-nowrap">{finding.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 p-5">
                <p className="font-bold">Ophthalmologist review</p>
                <Detail label="Reviewer" value="Ophthalmologist" />
                <Detail label="Decision" value={decision} />
                <Detail label="Reviewed at" value={reviewedAt} />
                <div className="mt-4 rounded-xl bg-slate-50 border border-slate-100 p-4">
                  <p className="text-xs text-slate-400">Clinical notes</p>
                  <p className="text-sm leading-relaxed mt-1 text-slate-700">{notes}</p>
                </div>
              </div>
            </div>
          </section>

          <section className="p-7 md:p-10 border-b border-slate-100">
            <SectionTitle eyebrow="05 · Recommendation" title="Follow-up recommendation" />
            <div className={`mt-6 rounded-2xl border p-5 ${referral ? "bg-rose-50 border-rose-200" : "bg-emerald-50 border-emerald-200"}`}>
              <p className={`font-bold ${referral ? "text-rose-800" : "text-emerald-800"}`}>{referral ? "Refer for ophthalmic care" : "Routine follow-up"}</p>
              <p className={`text-sm mt-2 leading-relaxed ${referral ? "text-rose-700" : "text-emerald-700"}`}>
                {referral ? "The case has been marked for specialist assessment or appropriate clinical follow-up." : "The reviewing clinician has accepted the screening assessment. Continue routine diabetic eye screening according to clinical guidance."}
              </p>
            </div>
          </section>

          <section className="p-7 md:p-10 bg-slate-50/70">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="rounded-2xl bg-amber-50 border border-amber-200 p-5">
                <p className="font-bold text-amber-900">Important clinical notice</p>
                <p className="text-sm text-amber-800 mt-2 leading-relaxed">This is an AI-assisted screening report, not a standalone medical diagnosis. Clinical decisions remain the responsibility of a qualified ophthalmologist.</p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="font-bold">Review completion</p>
                <p className="text-sm text-slate-500 mt-2">Case <strong>{item.id}</strong> was reviewed by an ophthalmologist and recorded in the RetinaSafe prototype workflow.</p>
                <div className="mt-5 grid grid-cols-2 gap-4">
                  <Signature label="PHC worker" />
                  <Signature label="Ophthalmologist" />
                </div>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-6">RetinaSafe · AI-assisted diabetic retinopathy screening · Human clinical review required · Report {reportId}</p>
          </section>
        </article>
      </main>
    </div>
  );
}

function SectionTitle({ eyebrow, title }) {
  return <div><p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">{eyebrow}</p><h3 className="text-2xl font-bold mt-2">{title}</h3></div>;
}
function Detail({ label, value }) { return <div className="rounded-2xl bg-slate-50 border border-slate-100 p-4 min-h-[76px]"><p className="text-xs text-slate-400">{label}</p><p className="font-semibold mt-1 text-slate-800 break-words">{value || "Not supplied"}</p></div>; }
function EvidencePanel({ title, src, empty }) { return <div className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-50"><div className="px-5 py-4 bg-white border-b border-slate-100"><p className="font-bold">{title}</p></div><div className="aspect-[4/3] flex items-center justify-center p-4">{src ? <img src={src} alt={title} className="max-h-full max-w-full object-contain rounded-xl" /> : <div className="text-center max-w-sm"><div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 mx-auto flex items-center justify-center text-teal-600 font-bold">◎</div><p className="font-semibold mt-4">Evidence pending</p><p className="text-xs text-slate-500 mt-2 leading-relaxed">{empty}</p></div>}</div></div>; }
function Signature({ label }) { return <div><div className="h-10 border-b border-dashed border-slate-300" /><p className="text-[11px] text-slate-400 mt-2">{label} signature</p></div>; }
function defaultFindings(quality) { return [{ title: "Retinal lesions", value: "Pending", detail: "Lesion-level output not supplied." }, { title: "Vessels", value: "Pending", detail: "Vessel assessment not supplied." }, { title: "Optic disc", value: "Pending", detail: "Optic disc assessment not supplied." }, { title: "Image quality", value: quality || "Pending", detail: "Quality result from the screening pipeline." }]; }

export default ClinicalReport;
