import { useEffect, useMemo, useState } from "react";

function DoctorCaseReview({ caseData, onBack, onGenerateReport }) {
  const [decision, setDecision] = useState("");
  const [notes, setNotes] = useState("");
  const [saved, setSaved] = useState(false);
  const [imageUrl, setImageUrl] = useState("");

  const item = caseData || {
    id: "RS-1025",
    patient: "Purna",
    age: "53",
    sex: "Male",
    eye: "Left Eye",
    result: "No Referable DR",
    confidence: 94,
    status: "Pending",
    clinic: "NIST Eye Hospital",
    date: "04 Sep 2026, 03:40 PM",
  };

  const isReferral = item.result === "Referable DR";
  const isMild = item.result === "Mild DR";

  useEffect(() => {
    if (!item.imageFile) {
      setImageUrl(item.imageUrl || "");
      return undefined;
    }

    const url = URL.createObjectURL(item.imageFile);
    setImageUrl(url);

    return () => URL.revokeObjectURL(url);
  }, [item.imageFile, item.imageUrl]);

  const findings = useMemo(
    () =>
      item.findings || [
        {
          title: "Retinal lesions",
          value: "Awaiting model output",
          detail: "Lesion-level findings will be populated from the screening pipeline.",
          tone: "neutral",
        },
        {
          title: "Vessels",
          value: "Awaiting model output",
          detail: "Vessel assessment will appear when the MATLAB analysis is connected.",
          tone: "neutral",
        },
        {
          title: "Optic disc",
          value: "Awaiting model output",
          detail: "Optic disc assessment will be supplied by the analysis pipeline.",
          tone: "neutral",
        },
        {
          title: "Image quality",
          value: item.quality || "Not supplied",
          detail: "Focus, illumination and field-of-view quality should come from the quality-check stage.",
          tone: item.quality ? "good" : "neutral",
        },
      ],
    [item.findings, item.quality]
  );

  function saveDecision() {
    if (!decision) return;
    setSaved(true);
  }

  function generateReport() {
    if (!saved || !decision) return;
    onGenerateReport?.({
      decision,
      notes,
      reviewedAt: new Date().toLocaleString("en-IN", {
        day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit"
      }),
    });
  }

  return (
    <div className="min-h-screen bg-[#f4f8f8] text-slate-900">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 h-[76px] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={onBack}
              className="w-11 h-11 rounded-2xl border border-slate-200 bg-white text-slate-700 font-bold text-lg hover:bg-slate-50 hover:border-slate-300 active:scale-95 transition-all"
              aria-label="Back to dashboard"
            >
              ←
            </button>

            <div className="w-11 h-11 rounded-2xl bg-[#071b20] text-white flex items-center justify-center font-bold">
              RS
            </div>

            <div>
              <h1 className="font-bold text-lg tracking-tight">RetinaSafe</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                Clinical review workspace
              </p>
            </div>
          </div>

          <div className="hidden sm:block text-right">
            <p className="text-xs text-slate-400">Case review</p>
            <p className="font-bold text-slate-800">{item.id}</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 py-8 lg:py-10 space-y-6">
        {/* HERO */}
        <section className="relative overflow-hidden rounded-[30px] bg-[#071b20] text-white p-7 md:p-9 shadow-xl shadow-slate-900/10">
          <div className="absolute -right-24 -top-28 w-80 h-80 rounded-full bg-teal-400/10 blur-3xl" />
          <div className="absolute -left-20 -bottom-32 w-72 h-72 rounded-full bg-cyan-400/10 blur-3xl" />

          <div className="relative flex flex-col lg:flex-row lg:items-end lg:justify-between gap-7">
            <div>
              <p className="text-[10px] uppercase tracking-[0.24em] text-teal-300 font-bold">
                Clinical review
              </p>
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight mt-3">
                Review screening case
              </h2>
              <p className="text-slate-300 mt-3 max-w-2xl leading-relaxed text-base md:text-lg">
                Inspect patient information, retinal evidence and explainable AI
                findings before recording the final clinical decision.
              </p>
            </div>

            <div
              className={`shrink-0 px-5 py-4 rounded-2xl border ${
                isReferral
                  ? "bg-amber-400/10 border-amber-300/20"
                  : isMild
                    ? "bg-yellow-400/10 border-yellow-300/20"
                    : "bg-teal-400/10 border-teal-300/20"
              }`}
            >
              <p className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">
                AI assessment
              </p>
              <p className="text-xl font-bold mt-1 text-teal-200">
                {item.result}
              </p>
              <p className="text-sm text-slate-300 mt-1">
                Confidence {item.confidence}%
              </p>
            </div>
          </div>
        </section>

        {/* REVIEW PROGRESS */}
        <section className="bg-white rounded-[26px] border border-slate-200 p-5 shadow-sm">
          <div className="flex flex-wrap items-center gap-2 md:gap-0 md:justify-between">
            {[
              ["01", "Patient"],
              ["02", "AI result"],
              ["03", "Evidence"],
              ["04", "Findings"],
              ["05", "Decision"],
            ].map(([number, label], index) => (
              <div key={number} className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-teal-50 border border-teal-100 text-teal-700 flex items-center justify-center text-xs font-bold">
                  {number}
                </div>
                <span className="text-xs sm:text-sm font-semibold text-slate-600">
                  {label}
                </span>
                {index < 4 && (
                  <span className="hidden md:block w-12 lg:w-20 h-px bg-slate-200 mx-2" />
                )}
              </div>
            ))}
          </div>
        </section>

        {/* PATIENT DETAILS */}
        <section className="grid lg:grid-cols-[minmax(0,1fr)_320px] gap-6">
          <div className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-6">
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                  Screening record
                </p>
                <h3 className="text-xl font-bold mt-1">Patient & screening details</h3>
              </div>
              <span className="text-xs font-bold text-slate-400">{item.date}</span>
            </div>

            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
              <Detail label="Patient" value={item.patient} />
              <Detail label="Age / Sex" value={`${item.age} years · ${item.sex}`} />
              <Detail label="Screened eye" value={item.eye} />
              <Detail label="Case ID" value={item.id} />
              <Detail label="PHC / Clinic" value={item.clinic} />
              <Detail label="AI confidence" value={`${item.confidence}%`} />
            </div>
          </div>

          <div className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
            <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
              Model output
            </p>
            <h3 className="text-xl font-bold mt-1">AI assessment</h3>

            <div
              className={`mt-5 rounded-2xl border p-5 ${
                isReferral
                  ? "bg-rose-50 border-rose-100"
                  : isMild
                    ? "bg-amber-50 border-amber-100"
                    : "bg-emerald-50 border-emerald-100"
              }`}
            >
              <p className="text-xs uppercase tracking-wider text-slate-400 font-bold">
                Classification
              </p>
              <p
                className={`text-2xl font-bold mt-2 ${
                  isReferral
                    ? "text-rose-700"
                    : isMild
                      ? "text-amber-700"
                      : "text-emerald-700"
                }`}
              >
                {item.result}
              </p>
              <div className="mt-4 h-2 rounded-full bg-white/80 overflow-hidden">
                <div
                  className="h-full rounded-full bg-teal-500 transition-all duration-700"
                  style={{ width: `${Math.min(Number(item.confidence) || 0, 100)}%` }}
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Model confidence: <strong>{item.confidence}%</strong>
              </p>
            </div>

            <p className="text-xs text-slate-500 mt-4 leading-relaxed">
              AI output is decision support. The reviewing ophthalmologist must
              inspect the available evidence before making a clinical decision.
            </p>
          </div>
        </section>

        {/* RETINAL EVIDENCE */}
        <section className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-6">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                Evidence review
              </p>
              <h3 className="text-2xl font-bold mt-1">Retinal evidence</h3>
              <p className="text-sm text-slate-500 mt-1">
                Compare the original fundus image with model explainability evidence.
              </p>
            </div>
            <span className="inline-flex w-fit px-3 py-1.5 rounded-full bg-slate-100 text-slate-500 text-xs font-bold">
              Case {item.id}
            </span>
          </div>

          <div className="grid lg:grid-cols-2 gap-5">
            <EvidenceCard
              title="Original fundus image"
              subtitle="Captured retinal image"
              imageUrl={imageUrl}
              emptyText="Fundus image will appear here"
            />

            <EvidenceCard
              title="Grad-CAM explanation"
              subtitle="Model attention visualization"
              imageUrl={item.gradCamUrl || item.gradcamUrl || ""}
              emptyText="Grad-CAM output will appear here"
              overlay={!item.gradCamUrl && !item.gradcamUrl}
            />
          </div>

          <div className="grid md:grid-cols-3 gap-4 mt-5">
            <EvidenceMeta label="Eye" value={item.eye || "Not supplied"} />
            <EvidenceMeta label="Image quality" value={item.quality || "Pending pipeline output"} />
            <EvidenceMeta label="Explainability" value={item.gradCamUrl ? "Available" : "Pending MATLAB output"} />
          </div>
        </section>

        {/* EXPLANATION */}
        <section className="grid lg:grid-cols-[1.2fr_0.8fr] gap-6">
          <div className="bg-[#071b20] rounded-[28px] p-6 md:p-7 text-white shadow-xl">
            <p className="text-[10px] uppercase tracking-[0.2em] text-teal-300 font-bold">
              Explainable AI
            </p>
            <h3 className="text-2xl font-bold mt-2">What the model focused on</h3>
            <p className="text-slate-300 text-sm leading-relaxed mt-3 max-w-2xl">
              Grad-CAM is intended to help the reviewer understand which image
              regions contributed most to the model prediction. It should be
              interpreted together with the original retinal image and clinical findings.
            </p>

            <div className="grid sm:grid-cols-3 gap-3 mt-6">
              <MiniEvidence title="Attention map" value={item.gradCamUrl ? "Available" : "Pending"} />
              <MiniEvidence title="Prediction" value={item.result} />
              <MiniEvidence title="Confidence" value={`${item.confidence}%`} />
            </div>
          </div>

          <div className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
            <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
              Interpretation guide
            </p>
            <h3 className="text-xl font-bold mt-1">Reviewer checklist</h3>
            <div className="mt-5 space-y-3">
              {[
                "Check image quality before interpreting lesions.",
                "Compare highlighted regions with the original fundus image.",
                "Confirm whether the AI classification is clinically plausible.",
                "Record referral or follow-up based on clinical judgment.",
              ].map((text) => (
                <div key={text} className="flex gap-3 rounded-2xl bg-slate-50 border border-slate-100 p-4">
                  <span className="w-6 h-6 rounded-full bg-teal-50 border border-teal-100 text-teal-700 flex items-center justify-center text-xs font-bold shrink-0">
                    ✓
                  </span>
                  <p className="text-sm text-slate-600 leading-relaxed">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CLINICAL FINDINGS */}
        <section className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
              Structured analysis
            </p>
            <h3 className="text-2xl font-bold mt-1">Clinical findings</h3>
            <p className="text-sm text-slate-500 mt-1">
              Structured observations reserved for the MATLAB screening pipeline.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mt-6">
            {findings.map((finding) => (
              <FindingCard key={finding.title} finding={finding} />
            ))}
          </div>
        </section>

        {/* DECISION */}
        <section className="grid lg:grid-cols-[minmax(0,1fr)_360px] gap-6">
          <div className="bg-white rounded-[28px] border border-slate-200 p-6 md:p-7 shadow-sm">
            <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
              Ophthalmologist review
            </p>
            <h3 className="text-2xl font-bold mt-1">Clinical decision</h3>
            <p className="text-sm text-slate-500 mt-2">
              Select the final clinical action after reviewing the evidence.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mt-6">
              <DecisionButton
                active={decision === "Approve AI assessment"}
                tone="teal"
                title="Approve AI assessment"
                description="AI result is clinically acceptable based on the reviewed evidence."
                onClick={() => setDecision("Approve AI assessment")}
              />

              <DecisionButton
                active={decision === "Refer for ophthalmic care"}
                tone="amber"
                title="Refer for ophthalmic care"
                description="Escalate the patient for specialist assessment or follow-up."
                onClick={() => setDecision("Refer for ophthalmic care")}
              />
            </div>

            <label className="block mt-5">
              <span className="text-sm font-bold text-slate-800">Clinical review notes</span>
              <textarea
                value={notes}
                onChange={(event) => setNotes(event.target.value)}
                placeholder="Document the clinical reasoning, observations or follow-up advice..."
                className="w-full mt-2 min-h-32 rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-800 outline-none resize-y focus:border-teal-500 focus:ring-4 focus:ring-teal-500/10 transition"
              />
            </label>

            <button
              type="button"
              onClick={saveDecision}
              disabled={!decision}
              className="w-full mt-4 rounded-2xl bg-[#071b20] text-white py-4 font-bold hover:bg-teal-700 active:scale-[0.99] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {saved ? "✓ Clinical decision saved" : "Save clinical decision"}
            </button>

            {saved && (
              <div className="mt-4 rounded-2xl bg-emerald-50 border border-emerald-100 p-4 text-sm text-emerald-700">
                <p className="font-bold">Review recorded</p>
                <p className="mt-1 text-emerald-700/80">
                  {decision} has been recorded for this prototype case.
                </p>
              </div>
            )}

            <button
              type="button"
              onClick={generateReport}
              disabled={!saved}
              className="w-full mt-3 rounded-2xl border border-teal-200 bg-teal-50 text-teal-800 py-4 font-bold hover:bg-teal-100 active:scale-[0.99] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              📄 Generate final clinical report
            </button>
          </div>

          <aside className="space-y-4">
            <div className="bg-[#071b20] text-white rounded-[28px] p-6 shadow-xl">
              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-300 font-bold">
                Final status
              </p>
              <p className="text-2xl font-bold mt-2">
                {saved ? "Reviewed" : "Awaiting decision"}
              </p>
              <div className="mt-5 pt-5 border-t border-white/10 space-y-3 text-sm">
                <StatusRow label="Case" value={item.id} />
                <StatusRow label="AI result" value={item.result} />
                <StatusRow label="Reviewer" value="Ophthalmologist" />
                <StatusRow label="Decision" value={decision || "Not recorded"} />
              </div>
            </div>

            <div className="bg-white rounded-[28px] border border-slate-200 p-6">
              <p className="font-bold">Clinical safety note</p>
              <p className="text-sm text-slate-500 leading-relaxed mt-2">
                RetinaSafe provides AI-assisted screening support. The AI result,
                confidence score and Grad-CAM visualization must not be treated as
                a standalone diagnosis.
              </p>
            </div>
          </aside>
        </section>

        <div className="flex items-center justify-between gap-4 pb-8">
          <button
            type="button"
            onClick={onBack}
            className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:bg-slate-50 transition"
          >
            ← Back to dashboard
          </button>
          <span className="hidden sm:block text-xs text-slate-400">
            Human clinical review required
          </span>
        </div>
      </main>
    </div>
  );
}

function Detail({ label, value }) {
  return (
    <div className="rounded-2xl bg-slate-50 border border-slate-100 p-4 min-h-[82px]">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="font-semibold mt-1 text-slate-800">{value || "Not supplied"}</p>
    </div>
  );
}

function EvidenceCard({ title, subtitle, imageUrl, emptyText, overlay = false }) {
  return (
    <div className="rounded-[24px] overflow-hidden border border-slate-200 bg-slate-50">
      <div className="px-5 py-4 bg-white border-b border-slate-100">
        <p className="font-bold text-slate-800">{title}</p>
        <p className="text-xs text-slate-400 mt-1">{subtitle}</p>
      </div>

      <div className="relative aspect-[16/10] bg-[#06171b] overflow-hidden flex items-center justify-center">
        {imageUrl ? (
          <img src={imageUrl} alt={title} className="w-full h-full object-contain" />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center p-8">
            {overlay && (
              <>
                <div className="absolute w-56 h-40 rounded-full bg-rose-500/10 blur-2xl" />
                <div className="absolute w-36 h-28 rounded-full bg-yellow-400/10 blur-xl translate-x-12 -translate-y-4" />
              </>
            )}
            <div className="relative w-48 h-32 rounded-[50%] border border-teal-300/20 bg-teal-300/[0.04] flex items-center justify-center">
              <div className="w-16 h-16 rounded-full border border-teal-300/20 bg-teal-300/5 flex items-center justify-center">
                <span className="text-[10px] uppercase tracking-widest text-teal-200 font-bold text-center px-3">
                  {emptyText}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="px-5 py-4 bg-white">
        <div className="flex items-center justify-between gap-3">
          <span className="text-xs text-slate-400">Evidence source</span>
          <span className="text-xs font-bold text-slate-600">
            {imageUrl ? "Available" : "Pending"}
          </span>
        </div>
      </div>
    </div>
  );
}

function EvidenceMeta({ label, value }) {
  return (
    <div className="rounded-2xl bg-slate-50 border border-slate-100 p-4">
      <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">{label}</p>
      <p className="text-sm font-semibold text-slate-700 mt-1">{value}</p>
    </div>
  );
}

function MiniEvidence({ title, value }) {
  return (
    <div className="rounded-2xl bg-white/[0.06] border border-white/10 p-4">
      <p className="text-[10px] uppercase tracking-wider text-slate-400">{title}</p>
      <p className="text-sm font-bold mt-2 text-teal-200 truncate">{value}</p>
    </div>
  );
}

function FindingCard({ finding }) {
  const good = finding.tone === "good";
  const warning = finding.tone === "warning";

  return (
    <div className="rounded-2xl border border-slate-200 p-5 hover:border-teal-200 transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-bold text-slate-800">{finding.title}</p>
          <p className="text-sm font-semibold mt-2 text-slate-600">{finding.value}</p>
        </div>
        <span
          className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
            good
              ? "bg-emerald-50 text-emerald-700"
              : warning
                ? "bg-amber-50 text-amber-700"
                : "bg-slate-50 text-slate-500"
          }`}
        >
          {good ? "✓" : warning ? "!" : "—"}
        </span>
      </div>
      <p className="text-xs text-slate-400 leading-relaxed mt-3">{finding.detail}</p>
    </div>
  );
}

function DecisionButton({ active, tone, title, description, onClick }) {
  const classes =
    tone === "amber"
      ? active
        ? "border-amber-400 bg-amber-50 ring-4 ring-amber-400/10"
        : "border-slate-200 hover:border-amber-300 hover:bg-amber-50/40"
      : active
        ? "border-teal-500 bg-teal-50 ring-4 ring-teal-500/10"
        : "border-slate-200 hover:border-teal-300 hover:bg-teal-50/40";

  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left rounded-2xl border p-5 transition-all duration-300 active:scale-[0.99] ${classes}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-bold text-slate-800">{title}</p>
          <p className="text-xs text-slate-500 mt-2 leading-relaxed">{description}</p>
        </div>
        <span
          className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs shrink-0 ${
            active
              ? tone === "amber"
                ? "bg-amber-500 border-amber-500 text-white"
                : "bg-teal-600 border-teal-600 text-white"
              : "border-slate-300 text-transparent"
          }`}
        >
          ✓
        </span>
      </div>
    </button>
  );
}

function StatusRow({ label, value }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="text-slate-400">{label}</span>
      <span className="text-right font-semibold text-slate-200 max-w-[180px]">{value}</span>
    </div>
  );
}

export default DoctorCaseReview;
