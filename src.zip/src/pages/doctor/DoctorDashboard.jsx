import { useMemo, useState } from "react";

function DoctorDashboard({ onBack, onReviewCase }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const cases = [
    {
      id: "RS-1025",
      patient: "Purna",
      age: "53",
      sex: "Male",
      eye: "Left Eye",
      result: "No Referable DR",
      confidence: 94,
      status: "Pending",
      clinic: "NIST Eye Hospital",
      date: "04 Sep 2026, 03:40 PM",
    },
    {
      id: "RS-1024",
      patient: "Ravi Kumar",
      age: "61",
      sex: "Male",
      eye: "Right Eye",
      result: "Referable DR",
      confidence: 91,
      status: "Pending",
      clinic: "PHC-018",
      date: "04 Sep 2026, 03:22 PM",
    },
    {
      id: "RS-1023",
      patient: "Anita Das",
      age: "47",
      sex: "Female",
      eye: "Left Eye",
      result: "Mild DR",
      confidence: 87,
      status: "Reviewed",
      clinic: "PHC-012",
      date: "04 Sep 2026, 02:56 PM",
    },
    {
      id: "RS-1022",
      patient: "Mohan Sahu",
      age: "58",
      sex: "Male",
      eye: "Right Eye",
      result: "Referable DR",
      confidence: 89,
      status: "Pending",
      clinic: "PHC-024",
      date: "04 Sep 2026, 02:31 PM",
    },
    {
      id: "RS-1021",
      patient: "Sunita Rout",
      age: "50",
      sex: "Female",
      eye: "Left Eye",
      result: "No Referable DR",
      confidence: 96,
      status: "Reviewed",
      clinic: "PHC-021",
      date: "04 Sep 2026, 01:48 PM",
    },
  ];

  const filteredCases = useMemo(() => {
    const query = search.trim().toLowerCase();

    return cases.filter((item) => {
      const matchesFilter =
        filter === "all" ||
        (filter === "pending" && item.status === "Pending") ||
        (filter === "reviewed" && item.status === "Reviewed") ||
        (filter === "referral" && item.result === "Referable DR");

      const matchesSearch =
        !query ||
        item.id.toLowerCase().includes(query) ||
        item.patient.toLowerCase().includes(query) ||
        item.clinic.toLowerCase().includes(query);

      return matchesFilter && matchesSearch;
    });
  }, [search, filter]);

  const pendingCount = cases.filter((item) => item.status === "Pending").length;
  const referralCount = cases.filter(
    (item) => item.result === "Referable DR"
  ).length;
  const reviewedCount = cases.filter(
    (item) => item.status === "Reviewed"
  ).length;

  return (
    <div className="min-h-screen bg-[#f4f8f8] text-slate-900">
      {/* HEADER */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-2xl bg-[#071b20] text-white flex items-center justify-center font-bold">
              RS
            </div>

            <div>
              <h1 className="font-bold text-lg tracking-tight">RetinaSafe</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                Ophthalmology workspace
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <p className="text-xs text-slate-400">Clinical reviewer</p>
              <p className="text-sm font-bold text-slate-800">
                Ophthalmologist
              </p>
            </div>

            <div className="w-10 h-10 rounded-full bg-teal-50 border border-teal-100 flex items-center justify-center text-teal-700 font-bold">
              DR
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 py-8">
        {/* TOP INTRO */}
        <section className="relative overflow-hidden rounded-[28px] bg-[#071b20] text-white p-7 md:p-9 shadow-xl shadow-slate-900/10">
          <div className="absolute -right-24 -top-28 w-72 h-72 rounded-full bg-teal-400/10 blur-3xl" />
          <div className="absolute -left-20 -bottom-32 w-64 h-64 rounded-full bg-cyan-400/10 blur-3xl" />

          <div className="relative flex flex-col lg:flex-row lg:items-end lg:justify-between gap-7">
            <div>
              <p className="text-[10px] uppercase tracking-[0.24em] text-teal-300 font-bold">
                Doctor portal
              </p>

              <h2 className="text-3xl md:text-4xl font-bold mt-3 tracking-tight">
                Clinical review dashboard
              </h2>

              <p className="text-slate-300 mt-3 max-w-2xl leading-relaxed">
                Review AI-assisted diabetic retinopathy screening cases,
                inspect retinal evidence and record the final clinical
                decision.
              </p>
            </div>

            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/10 border border-white/10">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <div>
                <p className="text-xs font-bold">Screening network online</p>
                <p className="text-[11px] text-slate-400">
                  Cases synchronized for review
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* STAT CARDS */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <StatCard
            label="Today's cases"
            value={cases.length}
            description="Screenings received"
          />

          <StatCard
            label="Pending review"
            value={pendingCount}
            description="Need clinical review"
            accent="teal"
          />

          <StatCard
            label="Referral cases"
            value={referralCount}
            description="AI flagged for referral"
            accent="amber"
          />

          <StatCard
            label="Reviewed"
            value={reviewedCount}
            description="Clinical decisions recorded"
          />
        </section>

        {/* QUEUE */}
        <section className="mt-6 bg-white border border-slate-200 rounded-[28px] shadow-sm overflow-hidden">
          <div className="p-6 md:p-7 border-b border-slate-100">
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-5">
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                  Review queue
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  Screening cases
                </h3>
                <p className="text-sm text-slate-500 mt-2">
                  Select a case to inspect the fundus image, AI result and
                  explainability evidence.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search patient or case ID..."
                  className="w-full sm:w-64 px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm outline-none focus:border-teal-400 focus:ring-4 focus:ring-teal-500/10 transition"
                />

                <select
                  value={filter}
                  onChange={(event) => setFilter(event.target.value)}
                  className="px-4 py-3 rounded-xl border border-slate-200 bg-white text-sm font-semibold outline-none focus:border-teal-400"
                >
                  <option value="all">All cases</option>
                  <option value="pending">Pending</option>
                  <option value="reviewed">Reviewed</option>
                  <option value="referral">Referral cases</option>
                </select>
              </div>
            </div>
          </div>

          {/* TABLE */}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-100">
                  <TableHead>Case</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Eye</TableHead>
                  <TableHead>AI classification</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Screened</TableHead>
                  <TableHead />
                </tr>
              </thead>

              <tbody>
                {filteredCases.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-slate-100 last:border-b-0 hover:bg-teal-50/30 transition-colors"
                  >
                    <td className="px-5 py-5">
                      <p className="font-bold text-slate-800">{item.id}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {item.clinic}
                      </p>
                    </td>

                    <td className="px-5 py-5">
                      <p className="font-semibold">{item.patient}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {item.age} yrs · {item.sex}
                      </p>
                    </td>

                    <td className="px-5 py-5 text-sm text-slate-600">
                      {item.eye}
                    </td>

                    <td className="px-5 py-5">
                      <ResultBadge result={item.result} />
                    </td>

                    <td className="px-5 py-5">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-sm">
                          {item.confidence}%
                        </span>
                        <div className="w-16 h-1.5 rounded-full bg-slate-200 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-teal-500"
                            style={{ width: `${item.confidence}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-5">
                      <StatusBadge status={item.status} />
                    </td>

                    <td className="px-5 py-5">
                      <p className="text-xs text-slate-500 whitespace-nowrap">
                        {item.date}
                      </p>
                    </td>

                    <td className="px-5 py-5 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          if (typeof onReviewCase === "function") {
                            onReviewCase(item);
                          }
                        }}
                        className="relative z-10 inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-slate-950 text-white text-xs font-bold hover:bg-teal-700 active:scale-[0.98] transition cursor-pointer select-none"
                      >
                        Review case
                      </button>
                    </td>
                  </tr>
                ))}

                {filteredCases.length === 0 && (
                  <tr>
                    <td colSpan="8" className="px-6 py-16 text-center">
                      <div className="text-4xl mb-3">⌕</div>
                      <p className="font-bold text-slate-800">
                        No cases found
                      </p>
                      <p className="text-sm text-slate-400 mt-1">
                        Try changing the search or filter.
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* CLINICAL NOTE */}
        <section className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
          <InfoCard
            title="AI-assisted workflow"
            text="AI results are intended to prioritize and support clinical review, not replace ophthalmologist assessment."
          />

          <InfoCard
            title="Explainable evidence"
            text="The case review screen will present the original fundus image alongside the model-generated Grad-CAM output."
          />

          <InfoCard
            title="Referral decision"
            text="The final referral decision should be recorded by the reviewing clinician after examining the available evidence."
          />
        </section>

        {/* BACK */}
        <div className="flex justify-start mt-7 pb-10">
          <button
            type="button"
            onClick={onBack}
            className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold hover:bg-slate-50 transition"
          >
            ← Back to role selection
          </button>
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value, description, accent = "default" }) {
  const accentClass =
    accent === "teal"
      ? "bg-teal-50 text-teal-700 border-teal-100"
      : accent === "amber"
        ? "bg-amber-50 text-amber-700 border-amber-100"
        : "bg-slate-50 text-slate-700 border-slate-100";

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
      <div
        className={`w-9 h-9 rounded-xl border flex items-center justify-center font-bold text-sm ${accentClass}`}
      >
        +
      </div>
      <p className="text-xs text-slate-500 mt-4">{label}</p>
      <p className="text-3xl font-bold mt-1">{value}</p>
      <p className="text-[11px] text-slate-400 mt-1">{description}</p>
    </div>
  );
}

function ResultBadge({ result }) {
  const isReferable = result === "Referable DR";
  const isMild = result === "Mild DR";

  const className = isReferable
    ? "bg-rose-50 text-rose-700 border-rose-200"
    : isMild
      ? "bg-amber-50 text-amber-700 border-amber-200"
      : "bg-emerald-50 text-emerald-700 border-emerald-200";

  return (
    <span
      className={`inline-flex px-3 py-1.5 rounded-full border text-xs font-bold whitespace-nowrap ${className}`}
    >
      {result}
    </span>
  );
}

function StatusBadge({ status }) {
  const reviewed = status === "Reviewed";

  return (
    <span
      className={`inline-flex px-3 py-1.5 rounded-full border text-xs font-bold ${
        reviewed
          ? "bg-slate-50 text-slate-600 border-slate-200"
          : "bg-teal-50 text-teal-700 border-teal-200"
      }`}
    >
      {status}
    </span>
  );
}

function TableHead({ children }) {
  return (
    <th className="px-5 py-4 text-left text-[10px] uppercase tracking-[0.14em] text-slate-400 font-bold">
      {children}
    </th>
  );
}

function InfoCard({ title, text }) {
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5">
      <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-100 text-teal-700 flex items-center justify-center font-bold">
        ✓
      </div>
      <h4 className="font-bold mt-4">{title}</h4>
      <p className="text-sm text-slate-500 mt-2 leading-relaxed">{text}</p>
    </div>
  );
}

export default DoctorDashboard;
