import { useEffect, useRef, useState } from "react";

function CaptureImage({
  selectedEye,
  imageFile,
  setImageFile,
  onNext,
  onBack,
}) {
  const fileInputRef = useRef(null);

  const [preview, setPreview] = useState(null);
  const [error, setError] = useState("");

  /* ========================================= */
  /* CREATE IMAGE PREVIEW */
  /* ========================================= */

  useEffect(() => {
    if (!imageFile) {
      setPreview(null);
      return;
    }

    const objectUrl = URL.createObjectURL(imageFile);

    setPreview(objectUrl);

    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [imageFile]);


  /* ========================================= */
  /* HANDLE IMAGE */
  /* ========================================= */

  const handleFile = (file) => {
    setError("");

    if (!file) {
      return;
    }

    if (!file.type.startsWith("image/")) {
      setError("Please select a valid image file.");
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setError("Image must be smaller than 15 MB.");
      return;
    }

    setImageFile(file);
  };


  /* ========================================= */
  /* FILE INPUT */
  /* ========================================= */

  const handleInputChange = (event) => {
    const file = event.target.files?.[0];

    handleFile(file);
  };


  /* ========================================= */
  /* DRAG AND DROP */
  /* ========================================= */

  const handleDrop = (event) => {
    event.preventDefault();

    const file = event.dataTransfer.files?.[0];

    handleFile(file);
  };


  /* ========================================= */
  /* REMOVE IMAGE */
  /* ========================================= */

  const removeImage = () => {
    setImageFile(null);
    setPreview(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };


  /* ========================================= */
  /* EYE NAME */
  /* ========================================= */

  const eyeName =
    selectedEye === "left"
      ? "Left Eye"
      : selectedEye === "right"
      ? "Right Eye"
      : "Eye";


  return (
    <div className="min-h-screen bg-slate-50">

      {/* ========================================= */}
      {/* HEADER */}
      {/* ========================================= */}

      <header className="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center">
            <span className="text-xl">
              👁️
            </span>
          </div>

          <div>

            <h1 className="font-bold text-slate-900">
              RetinaSafe
            </h1>

            <p className="text-xs text-slate-500">
              PHC Screening
            </p>

          </div>

        </div>


        <div className="text-sm text-slate-500">
          Step <b className="text-slate-900">3</b> of 6
        </div>

      </header>


      {/* ========================================= */}
      {/* PROGRESS */}
      {/* ========================================= */}

      <ProgressBar active={2} />


      {/* ========================================= */}
      {/* MAIN */}
      {/* ========================================= */}

      <main className="max-w-4xl mx-auto px-6 py-10">

        {/* TITLE */}

        <div className="text-center mb-8">

          <span className="inline-flex px-3 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold">
            STEP 3 · CAPTURE
          </span>


          <h2 className="text-4xl font-bold text-slate-900 mt-5">
            Capture fundus image
          </h2>


          <p className="text-slate-500 mt-3">
            Capture or upload a clear retinal image for screening.
          </p>


          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-slate-200 text-sm text-slate-700">

            <span>
              👁️
            </span>

            Screening:

            <b>
              {eyeName}
            </b>

          </div>

        </div>


        {/* ========================================= */}
        {/* IMAGE CARD */}
        {/* ========================================= */}

        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-sm">

          {!preview ? (

            /* ===================================== */
            /* EMPTY IMAGE STATE */
            /* ===================================== */

            <div
              onDragOver={(event) => event.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[380px] rounded-2xl border-2 border-dashed border-slate-300 hover:border-slate-500 hover:bg-slate-50 transition cursor-pointer flex flex-col items-center justify-center text-center px-6"
            >

              <div className="w-20 h-20 rounded-2xl bg-slate-100 flex items-center justify-center text-4xl mb-5">
                📷
              </div>


              <h3 className="text-xl font-semibold text-slate-900">
                Add fundus image
              </h3>


              <p className="text-slate-500 mt-2 max-w-md">
                Drag and drop a retinal image here, or click to browse
                from this device.
              </p>


              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="mt-6 px-6 py-3 rounded-xl bg-slate-950 text-white font-semibold hover:bg-slate-800 transition"
              >
                Upload Image
              </button>


              <p className="text-xs text-slate-400 mt-4">
                JPG, JPEG or PNG · Maximum 15 MB
              </p>

            </div>

          ) : (

            /* ===================================== */
            /* IMAGE PREVIEW */
            /* ===================================== */

            <div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">

                <div>

                  <p className="font-semibold text-slate-900">
                    Image preview
                  </p>

                  <p className="text-sm text-slate-500 mt-1">
                    {imageFile?.name}
                  </p>

                </div>


                <div className="px-3 py-1.5 rounded-full bg-slate-100 text-slate-700 text-sm">
                  ✓ Image loaded
                </div>

              </div>


              {/* IMAGE */}

              <div className="relative rounded-2xl overflow-hidden bg-slate-950 min-h-[380px] flex items-center justify-center">

                <img
                  src={preview}
                  alt={`${eyeName} fundus`}
                  className="max-h-[520px] max-w-full object-contain"
                />

              </div>


              {/* IMAGE INFO */}

              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-5">

                <div className="text-sm text-slate-500">

                  <span className="font-medium text-slate-700">
                    Selected:
                  </span>{" "}

                  {eyeName}

                </div>


                <button
                  type="button"
                  onClick={removeImage}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 transition"
                >
                  Replace Image
                </button>

              </div>

            </div>

          )}

        </div>


        {/* ========================================= */}
        {/* ERROR */}
        {/* ========================================= */}

        {error && (
          <div className="mt-4 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
            ⚠️ {error}
          </div>
        )}


        {/* ========================================= */}
        {/* IMAGE QUALITY TIPS */}
        {/* ========================================= */}

        <div className="grid md:grid-cols-3 gap-4 mt-6">

          <InfoCard
            icon="💡"
            title="Good lighting"
            text="Avoid very dark or overexposed images."
          />


          <InfoCard
            icon="🎯"
            title="Clear focus"
            text="Keep the retinal structures sharp."
          />


          <InfoCard
            icon="👁️"
            title="Full field"
            text="Capture as much of the retina as possible."
          />

        </div>


        {/* ========================================= */}
        {/* NAVIGATION */}
        {/* ========================================= */}

        <div className="flex items-center justify-between mt-8">

          <button
            type="button"
            onClick={onBack}
            className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 transition"
          >
            ← Back
          </button>


          <button
            type="button"
            disabled={!imageFile}
            onClick={onNext}
            className={`px-7 py-3 rounded-xl font-semibold transition ${
              imageFile
                ? "bg-slate-950 text-white hover:bg-slate-800"
                : "bg-slate-200 text-slate-400 cursor-not-allowed"
            }`}
          >
            Continue →
          </button>

        </div>

      </main>


      {/* HIDDEN FILE INPUT */}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/jpg"
        onChange={handleInputChange}
        className="hidden"
      />

    </div>
  );
}


/* ================================================= */
/* INFO CARD */
/* ================================================= */

function InfoCard({
  icon,
  title,
  text,
}) {
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5">

      <div className="text-2xl mb-3">
        {icon}
      </div>

      <h3 className="font-semibold text-slate-900">
        {title}
      </h3>

      <p className="text-sm text-slate-500 mt-1 leading-relaxed">
        {text}
      </p>

    </div>
  );
}


/* ================================================= */
/* PROGRESS BAR */
/* ================================================= */

function ProgressBar({ active }) {

  const steps = [
    "Patient",
    "Eye",
    "Capture",
    "Quality",
    "Analysis",
    "Result",
  ];


  return (
    <div className="bg-white border-b border-slate-200 px-6 py-5">

      <div className="max-w-5xl mx-auto flex items-center">

        {steps.map((step, index) => (

          <div
            key={step}
            className="flex items-center flex-1"
          >

            <div className="flex items-center gap-2">

              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  index <= active
                    ? "bg-slate-950 text-white"
                    : "bg-slate-100 text-slate-400"
                }`}
              >
                {index + 1}
              </div>


              <span
                className={`hidden sm:block text-xs font-semibold ${
                  index <= active
                    ? "text-slate-900"
                    : "text-slate-400"
                }`}
              >
                {step}
              </span>

            </div>


            {index < steps.length - 1 && (
              <div className="flex-1 h-px bg-slate-200 mx-3" />
            )}

          </div>

        ))}

      </div>

    </div>
  );
}


export default CaptureImage;