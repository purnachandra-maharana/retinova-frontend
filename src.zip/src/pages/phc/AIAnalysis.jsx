import { useEffect, useState } from "react";

function AIAnalysis({
  selectedEye,
  imageFile,
  onNext,
  onBack,
}) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completed, setCompleted] = useState(false);

  const analysisSteps = [
    {
      title: "Image preprocessing",
      description: "Preparing the retinal image for AI analysis.",
    },
    {
      title: "Retinal structure analysis",
      description: "Examining vessels, optic disc and retinal structures.",
    },
    {
      title: "DR classification",
      description: "Running diabetic retinopathy classification.",
    },
    {
      title: "Lesion analysis",
      description: "Checking for visible retinal abnormalities.",
    },
    {
      title: "Grad-CAM explanation",
      description: "Generating visual evidence for the AI prediction.",
    },
  ];

  useEffect(() => {
    if (currentStep >= analysisSteps.length) {
      setCompleted(true);
      return;
    }

    const timer = setTimeout(() => {
      setCurrentStep((previous) => previous + 1);
    }, 900);

    return () => clearTimeout(timer);
  }, [currentStep]);

  return (
    <div className="min-h-screen bg-slate-50">

      {/* HEADER */}
      <header className="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center">
            <span className="text-xl">👁️</span>
          </div>

          <div>
            <h1 className="font-bold text-slate-900">
              RetinaSafe
            </h1>

            <p className="text-xs text-slate-500">
              PHC Screening
            </p>
          </div>

        </div>

        <span className="text-sm text-slate-500">
          Step <b className="text-slate-900">5</b> of 6
        </span>

      </header>


      {/* PROGRESS */}
      <ProgressBar active={4} />


      {/* MAIN */}
      <main className="max-w-4xl mx-auto px-6 py-10">

        <div className="text-center">

          <span className="inline-flex px-4 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold">
            STEP 5 · AI ANALYSIS
          </span>

          <h2 className="text-4xl font-bold text-slate-900 mt-5">
            AI retinal analysis
          </h2>

          <p className="text-slate-500 mt-3">
            The system is analyzing the retinal image for diabetic retinopathy.
          </p>

          {selectedEye && (
            <div className="inline-flex items-center gap-2 mt-5 px-4 py-2 rounded-full bg-white border border-slate-200 text-sm text-slate-600">
              👁️
              {selectedEye === "left" ? "Left Eye" : "Right Eye"}
            </div>
          )}

        </div>


        {/* IMAGE */}
        {imageFile && (
          <div className="bg-white border border-slate-200 rounded-3xl p-5 mt-10 shadow-sm">

            <div className="flex items-center justify-between mb-4">

              <div>
                <h3 className="font-semibold text-slate-900">
                  Fundus Image
                </h3>

                <p className="text-sm text-slate-500 mt-1">
                  {imageFile.name || "Uploaded retinal image"}
                </p>
              </div>

              <span className="px-3 py-1.5 rounded-full bg-slate-100 text-xs font-semibold text-slate-600">
                {selectedEye === "left" ? "Left Eye" : "Right Eye"}
              </span>

            </div>


            <div className="rounded-2xl overflow-hidden bg-slate-950">

              <img
                src={URL.createObjectURL(imageFile)}
                alt="Fundus"
                className="w-full max-h-[420px] object-contain"
              />

            </div>

          </div>
        )}


        {/* ANALYSIS PIPELINE */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 mt-6 shadow-sm">

          <h3 className="text-xl font-bold text-slate-900">
            Analysis pipeline
          </h3>

          <p className="text-slate-500 mt-2">
            Each stage will later connect to the MATLAB AI pipeline.
          </p>


          <div className="mt-8 space-y-4">

            {analysisSteps.map((step, index) => {

              const isDone = index < currentStep;
              const isRunning = index === currentStep && !completed;
              const isWaiting = index > currentStep;

              return (
                <div
                  key={step.title}
                  className={`flex items-center gap-4 p-5 rounded-2xl border transition ${
                    isDone
                      ? "border-slate-200 bg-slate-50"
                      : isRunning
                      ? "border-slate-900 bg-white shadow-sm"
                      : "border-slate-100 bg-slate-50/50"
                  }`}
                >

                  {/* STATUS */}
                  <div
                    className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 font-bold ${
                      isDone
                        ? "bg-slate-950 text-white"
                        : isRunning
                        ? "bg-slate-200 text-slate-900"
                        : "bg-slate-100 text-slate-400"
                    }`}
                  >
                    {isDone ? "✓" : index + 1}
                  </div>


                  {/* TEXT */}
                  <div className="flex-1">

                    <h4
                      className={`font-semibold ${
                        isWaiting
                          ? "text-slate-400"
                          : "text-slate-900"
                      }`}
                    >
                      {step.title}
                    </h4>

                    <p className="text-sm text-slate-500 mt-1">
                      {step.description}
                    </p>

                  </div>


                  {/* STATUS TEXT */}
                  <div className="text-sm font-medium">

                    {isDone && (
                      <span className="text-slate-700">
                        Complete
                      </span>
                    )}

                    {isRunning && (
                      <span className="text-slate-900">
                        Analyzing...
                      </span>
                    )}

                    {isWaiting && (
                      <span className="text-slate-400">
                        Waiting
                      </span>
                    )}

                  </div>

                </div>
              );
            })}

          </div>


          {/* COMPLETED */}
          {completed && (

            <div className="mt-8 p-5 rounded-2xl border border-emerald-200 bg-emerald-50">

              <div className="flex items-start gap-3">

                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                  ✓
                </div>

                <div>

                  <h4 className="font-semibold text-emerald-900">
                    AI analysis completed
                  </h4>

                  <p className="text-sm text-emerald-700 mt-1">
                    The retinal image has been processed successfully.
                    Continue to view the screening result.
                  </p>

                </div>

              </div>

            </div>

          )}

        </div>


        {/* NAVIGATION */}
        <div className="flex items-center justify-between mt-6">

          <button
            type="button"
            onClick={onBack}
            className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
          >
            ← Back
          </button>


          <button
            type="button"
            disabled={!completed}
            onClick={onNext}
            className={`px-6 py-3 rounded-xl font-semibold transition ${
              completed
                ? "bg-slate-950 text-white hover:bg-slate-800"
                : "bg-slate-200 text-slate-400 cursor-not-allowed"
            }`}
          >
            View Result →
          </button>

        </div>

      </main>

    </div>
  );
}


/* ================================================= */
/* PROGRESS BAR */
/* ================================================= */

function ProgressBar({ active }) {

  const steps = [
    "Patient",
    "Eye",
    "Capture",
    "Quality",
    "Analysis",
    "Result",
  ];

  return (
    <div className="bg-white border-b border-slate-200 px-6 py-5">

      <div className="max-w-5xl mx-auto flex items-center">

        {steps.map((step, index) => (

          <div
            key={step}
            className="flex items-center flex-1"
          >

            <div className="flex items-center gap-2">

              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  index <= active
                    ? "bg-slate-950 text-white"
                    : "bg-slate-100 text-slate-400"
                }`}
              >
                {index + 1}
              </div>

              <span
                className={`hidden sm:block text-xs font-semibold ${
                  index <= active
                    ? "text-slate-900"
                    : "text-slate-400"
                }`}
              >
                {step}
              </span>

            </div>

            {index < steps.length - 1 && (
              <div className="flex-1 h-px bg-slate-200 mx-3" />
            )}

          </div>

        ))}

      </div>

    </div>
  );
}


export default AIAnalysis;