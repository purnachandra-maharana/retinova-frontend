import { useEffect, useMemo, useState } from "react";

function ScreeningResult({
  patient,
  selectedEye,
  imageFile,
  onBack,
  onRestart,
}) {
  const eyeName =
    selectedEye === "left"
      ? "Left Eye"
      : selectedEye === "right"
      ? "Right Eye"
      : "Eye";

  const [imageDataUrl, setImageDataUrl] = useState("");
  const [gradCamDataUrl, setGradCamDataUrl] = useState("");
  const [isPreparingImage, setIsPreparingImage] = useState(false);
  const [isReportOpening, setIsReportOpening] = useState(false);

  /*
   * Prototype result.
   *
   * IMPORTANT:
   * Replace these values with the response from the MATLAB/backend
   * once the real ResNet50 + Grad-CAM pipeline is connected.
   */
  const aiResult = useMemo(
    () => ({
      classification: "No Referable DR",
      confidence: 94,
      recommendation: "Routine follow-up",
      referral: "No referral indicated by the screening model",
      model: "RetinaSafe DR Screening Model",
      modelVersion: "Prototype v1.0",
    }),
    []
  );

  const reportId = useMemo(() => {
    const id = patient?.patientId || "PATIENT";
    const timePart = new Date()
      .toISOString()
      .replace(/\D/g, "")
      .slice(-8);

    return `RS-${String(id).replace(/[^a-zA-Z0-9]/g, "").slice(0, 12)}-${timePart}`;
  }, [patient?.patientId]);

  const screeningDateTime = useMemo(() => {
    const now = new Date();

    return {
      date: now.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      time: now.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      full: now.toLocaleString("en-IN", {
        dateStyle: "medium",
        timeStyle: "short",
      }),
    };
  }, []);

  const clinicName =
    patient?.clinicName ||
    patient?.phcName ||
    "Primary Health Centre";

  const clinicId =
    patient?.clinicId ||
    patient?.phcId ||
    "Not provided";

  const clinicLocation =
    patient?.clinicLocation ||
    patient?.location ||
    [patient?.village, patient?.district, patient?.state]
      .filter(Boolean)
      .join(", ") ||
    "Not provided";

  const clinicPhone =
    patient?.clinicPhone ||
    "Not provided";

  const patientName =
    patient?.fullName || "Patient name not provided";

  const patientId =
    patient?.patientId || "Not available";

  const workerName =
    patient?.workerName || "Not provided";

  const workerId =
    patient?.workerId || "Not provided";

  const workerDesignation =
    patient?.workerDesignation || "Screening operator";

  const age =
    patient?.age || "Not provided";

  const sex =
    patient?.sex || "Not provided";

  const dob =
    patient?.dob || "Not provided";

  const phone =
    patient?.phone || "Not provided";

  const address =
    patient?.address || "Not provided";

  const diabetesType =
    patient?.diabetesType || "Not provided";

  const diabetesSince =
    patient?.diabetesSince || "Not provided";

  const treatment =
    patient?.treatment || "Not provided";

  const hba1c =
    patient?.hba1c || "Not provided";

  const previousDR =
    patient?.previousDR || "Not provided";

  const previousEyeTreatment =
    patient?.previousEyeTreatment || "Not provided";

  const screeningReason =
    patient?.screeningReason || "Routine diabetic retinopathy screening";

  /* =========================================================
     IMAGE → DATA URL
     ========================================================= */

  useEffect(() => {
    let cancelled = false;

    const loadImage = async () => {
      if (!imageFile) {
        setImageDataUrl("");
        setGradCamDataUrl("");
        return;
      }

      setIsPreparingImage(true);

      try {
        let dataUrl = "";

        if (typeof imageFile === "string") {
          dataUrl = imageFile;
        } else if (imageFile instanceof Blob) {
          dataUrl = await fileToDataUrl(imageFile);
        }

        if (cancelled || !dataUrl) {
          return;
        }

        setImageDataUrl(dataUrl);

        /*
         * This is a VISUAL PROTOTYPE only.
         * The real Grad-CAM should come from MATLAB/backend.
         */
        const gradCam = await createPrototypeGradCam(dataUrl);

        if (!cancelled) {
          setGradCamDataUrl(gradCam);
        }
      } catch (error) {
        console.error("Image processing error:", error);

        if (!cancelled) {
          setImageDataUrl("");
          setGradCamDataUrl("");
        }
      } finally {
        if (!cancelled) {
          setIsPreparingImage(false);
        }
      }
    };

    loadImage();

    return () => {
      cancelled = true;
    };
  }, [imageFile]);

  /* =========================================================
     REPORT
     ========================================================= */

  const handleGenerateReport = () => {
    if (!imageDataUrl) {
      alert("Fundus image is not available. Please upload an image first.");
      return;
    }

    setIsReportOpening(true);

    const reportWindow = window.open(
      "",
      "_blank",
      "width=1100,height=900"
    );

    if (!reportWindow) {
      setIsReportOpening(false);
      alert("Please allow pop-ups in your browser to generate the report.");
      return;
    }

    const reportGradCam = gradCamDataUrl || imageDataUrl;

    const html = buildClinicalReportHtml({
      patient,
      patientName,
      patientId,
      eyeName,
      clinicName,
      clinicId,
      clinicLocation,
      clinicPhone,
      workerName,
      workerId,
      workerDesignation,
      age,
      sex,
      dob,
      phone,
      address,
      diabetesType,
      diabetesSince,
      treatment,
      hba1c,
      previousDR,
      previousEyeTreatment,
      screeningReason,
      reportId,
      screeningDateTime,
      imageDataUrl,
      gradCamDataUrl: reportGradCam,
      aiResult,
    });

    reportWindow.document.open();
    reportWindow.document.write(html);
    reportWindow.document.close();

    setTimeout(() => {
      setIsReportOpening(false);
    }, 800);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSendToDoctor = () => {
    alert(
      `Case ${reportId} is prepared for ophthalmologist review.\n\n` +
        "Doctor communication is currently a prototype action."
    );
  };

  const confidenceWidth = `${Math.min(
    100,
    Math.max(0, Number(aiResult.confidence) || 0)
  )}%`;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* =====================================================
          HEADER
          ===================================================== */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-20 flex items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="relative w-11 h-11 rounded-2xl bg-slate-950 overflow-hidden flex items-center justify-center">
              <div className="w-7 h-4 rounded-[50%] border-2 border-teal-300 rotate-[-8deg]" />
              <div className="absolute w-2.5 h-2.5 rounded-full bg-teal-300" />
            </div>

            <div>
              <h1 className="font-extrabold text-lg tracking-tight">
                RetinaSafe
              </h1>
              <p className="text-xs text-slate-500">
                {clinicName}
              </p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-[0.18em] text-slate-400 font-bold">
                Report
              </p>
              <p className="text-sm font-semibold text-slate-700">
                {reportId}
              </p>
            </div>

            <div className="h-8 w-px bg-slate-200" />

            <div className="text-right">
              <p className="text-[10px] uppercase tracking-[0.18em] text-slate-400 font-bold">
                Workflow
              </p>
              <p className="text-sm font-semibold">
                Step 6 of 6
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* =====================================================
          PROGRESS
          ===================================================== */}
      <ProgressBar />

      <main className="max-w-7xl mx-auto px-5 md:px-8 py-10">
        {/* ===================================================
            TITLE
            =================================================== */}
        <section className="relative overflow-hidden rounded-[2rem] bg-slate-950 text-white p-7 md:p-10 shadow-xl">
          <div className="absolute -right-20 -top-24 w-72 h-72 rounded-full bg-teal-400/20 blur-3xl" />
          <div className="absolute -left-24 -bottom-28 w-80 h-80 rounded-full bg-cyan-400/10 blur-3xl" />

          <div className="relative flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-teal-300/20 bg-teal-300/10 text-teal-200 text-xs font-bold tracking-wide">
                <span className="w-2 h-2 rounded-full bg-teal-300 animate-pulse" />
                SCREENING COMPLETED
              </div>

              <h2 className="text-4xl md:text-5xl font-black tracking-tight mt-5">
                Screening Result
              </h2>

              <p className="text-slate-300 mt-3 max-w-2xl leading-relaxed">
                AI-assisted diabetic retinopathy screening for{" "}
                <span className="text-white font-semibold">
                  {patientName}
                </span>
                . Review the model result, retinal evidence and recommended
                next step below.
              </p>
            </div>

            <div className="lg:text-right">
              <p className="text-xs uppercase tracking-[0.18em] text-slate-400 font-bold">
                Screening timestamp
              </p>
              <p className="text-lg font-semibold mt-1">
                {screeningDateTime.full}
              </p>
              <p className="text-sm text-slate-400 mt-1">
                {eyeName}
              </p>
            </div>
          </div>
        </section>

        {/* ===================================================
            PATIENT + OPERATOR
            =================================================== */}
        <section className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-6">
          <div className="xl:col-span-2 bg-white border border-slate-200 rounded-[1.75rem] p-6 md:p-8 shadow-sm">
            <SectionHeading
              eyebrow="PATIENT RECORD"
              title="Patient information"
              description="Identity and clinical context captured during registration."
            />

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
              <InfoTile label="Full name" value={patientName} wide />
              <InfoTile label="Patient ID" value={patientId} />
              <InfoTile label="Age" value={age} />
              <InfoTile label="Sex" value={sex} />
              <InfoTile label="Date of birth" value={dob} />
              <InfoTile label="Phone" value={phone} />
              <InfoTile label="Eye screened" value={eyeName} />
              <InfoTile label="Screening reason" value={screeningReason} />
            </div>

            <div className="mt-4 rounded-2xl bg-slate-50 border border-slate-200 p-4">
              <p className="text-[10px] uppercase tracking-[0.16em] font-bold text-slate-400">
                Address
              </p>
              <p className="text-sm font-semibold text-slate-700 mt-1">
                {address}
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-[1.75rem] p-6 md:p-8 shadow-sm">
            <SectionHeading
              eyebrow="SCREENING SITE"
              title="Clinic & operator"
              description="Personnel and facility responsible for this screening."
            />

            <div className="mt-6 space-y-3">
              <InfoRow label="Clinic / PHC" value={clinicName} />
              <InfoRow label="Clinic ID" value={clinicId} />
              <InfoRow label="Location" value={clinicLocation} />
              <InfoRow label="Clinic phone" value={clinicPhone} />
              <div className="h-px bg-slate-200 my-4" />
              <InfoRow label="Screening operator" value={workerName} />
              <InfoRow label="Employee ID" value={workerId} />
              <InfoRow label="Designation" value={workerDesignation} />
            </div>
          </div>
        </section>

        {/* ===================================================
            MEDICAL DETAILS
            =================================================== */}
        <section className="bg-white border border-slate-200 rounded-[1.75rem] p-6 md:p-8 mt-6 shadow-sm">
          <SectionHeading
            eyebrow="CLINICAL CONTEXT"
            title="Diabetes history"
            description="Medical details supplied during patient registration."
          />

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
            <InfoTile label="Diabetes type" value={diabetesType} />
            <InfoTile label="Diagnosed since" value={diabetesSince} />
            <InfoTile label="HbA1c" value={hba1c} />
            <InfoTile label="Treatment" value={treatment} />
            <InfoTile label="Previous DR" value={previousDR} />
            <InfoTile
              label="Previous eye treatment"
              value={previousEyeTreatment}
            />
          </div>
        </section>

        {/* ===================================================
            AI RESULT
            =================================================== */}
        <section className="grid grid-cols-1 lg:grid-cols-[1.25fr_0.75fr] gap-6 mt-6">
          <div className="bg-white border border-slate-200 rounded-[1.75rem] p-6 md:p-8 shadow-sm">
            <div className="flex items-start justify-between gap-5">
              <SectionHeading
                eyebrow="MODEL OUTPUT"
                title="AI screening classification"
                description="Current prototype classification for the screened fundus image."
              />

              <div className="shrink-0 w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 text-xl font-black">
                ✓
              </div>
            </div>

            <div className="mt-7 rounded-3xl border border-emerald-200 bg-emerald-50/70 p-6">
              <p className="text-xs uppercase tracking-[0.16em] font-bold text-emerald-700">
                Screening classification
              </p>

              <h3 className="text-3xl md:text-4xl font-black text-emerald-950 mt-2">
                {aiResult.classification}
              </h3>

              <p className="text-sm text-emerald-800 mt-3 max-w-xl leading-relaxed">
                No referable diabetic retinopathy detected in the screened
                image according to the current AI screening output.
              </p>

              <div className="mt-6">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-emerald-800">
                    AI confidence
                  </span>
                  <span className="text-emerald-950">
                    {aiResult.confidence}%
                  </span>
                </div>

                <div className="mt-2 h-3 bg-white/80 border border-emerald-200 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-emerald-500 transition-all duration-1000"
                    style={{ width: confidenceWidth }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 text-white rounded-[1.75rem] p-6 md:p-8 shadow-sm">
            <p className="text-xs uppercase tracking-[0.16em] font-bold text-teal-300">
              MODEL DETAILS
            </p>

            <h3 className="text-xl font-bold mt-3">
              Screening system
            </h3>

            <div className="mt-6 space-y-4">
              <DarkInfoRow label="Model" value={aiResult.model} />
              <DarkInfoRow label="Version" value={aiResult.modelVersion} />
              <DarkInfoRow label="Eye" value={eyeName} />
              <DarkInfoRow label="Report ID" value={reportId} />
              <DarkInfoRow
                label="Result generated"
                value={screeningDateTime.full}
              />
            </div>
          </div>
        </section>

        {/* ===================================================
            EXPLAINABLE AI
            =================================================== */}
        <section className="bg-white border border-slate-200 rounded-[1.75rem] mt-6 p-6 md:p-8 shadow-sm">
          <SectionHeading
            eyebrow="EXPLAINABLE AI"
            title="Retinal evidence"
            description="The original image and attention visualization are shown together for clinical review."
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-7">
            <ImagePanel
              title="Original fundus image"
              subtitle={eyeName}
              image={imageDataUrl}
              loading={isPreparingImage}
              fallback="Fundus image unavailable"
            />

            <ImagePanel
              title="Grad-CAM explanation"
              subtitle="AI attention visualization"
              image={gradCamDataUrl}
              loading={isPreparingImage}
              fallback="Grad-CAM unavailable"
            />
          </div>

          <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4">
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-amber-800">
              Explainability status
            </p>
            <p className="text-sm text-amber-900 mt-1 leading-relaxed">
              The Grad-CAM shown in this frontend prototype is a visual
              placeholder. Connect it to the MATLAB{" "}
              <span className="font-semibold">
                generateGradCAM.m
              </span>{" "}
              output before presenting it as model-generated clinical
              evidence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <ExplanationCard
              title="Retinal vessels"
              text="No major vessel abnormalities identified by the current prototype observation."
            />

            <ExplanationCard
              title="Optic disc"
              text="Optic disc region appears within expected limits in the current prototype result."
            />

            <ExplanationCard
              title="Lesion regions"
              text="No prominent lesion pattern identified in the current prototype observation."
            />
          </div>
        </section>

        {/* ===================================================
            RECOMMENDATION
            =================================================== */}
        <section className="grid grid-cols-1 lg:grid-cols-[1fr_0.75fr] gap-6 mt-6">
          <div className="bg-white border border-slate-200 rounded-[1.75rem] p-6 md:p-8 shadow-sm">
            <SectionHeading
              eyebrow="NEXT STEP"
              title="Clinical recommendation"
              description="Suggested action based on the current screening classification."
            />

            <div className="mt-6 rounded-3xl border border-emerald-200 bg-emerald-50 p-6">
              <div className="flex gap-4">
                <div className="w-11 h-11 rounded-2xl bg-emerald-500 text-white flex items-center justify-center text-lg font-black shrink-0">
                  ✓
                </div>

                <div>
                  <h3 className="text-xl font-black text-emerald-950">
                    {aiResult.recommendation}
                  </h3>

                  <p className="text-sm text-emerald-800 mt-2 leading-relaxed">
                    Continue routine diabetic eye screening according to
                    applicable clinical guidance. Escalate for professional
                    review if symptoms, image-quality concerns or other
                    clinical findings warrant it.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-[1.75rem] border border-amber-200 bg-amber-50 p-6 md:p-8">
            <p className="text-xs uppercase tracking-[0.16em] font-bold text-amber-700">
              CLINICAL SAFETY
            </p>

            <h3 className="text-xl font-black text-amber-950 mt-3">
              Human review required
            </h3>

            <p className="text-sm text-amber-900 mt-3 leading-relaxed">
              This is an AI-assisted screening output, not a definitive
              medical diagnosis. A qualified ophthalmologist should review
              cases that require clinical attention.
            </p>

            <div className="mt-5 pt-5 border-t border-amber-200">
              <p className="text-xs font-bold text-amber-800">
                Referral status
              </p>
              <p className="text-sm font-semibold text-amber-950 mt-1">
                {aiResult.referral}
              </p>
            </div>
          </div>
        </section>

        {/* ===================================================
            ACTIONS
            =================================================== */}
        <section className="mt-8">
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 bg-white font-bold text-slate-700 hover:bg-slate-50 transition"
            >
              Print Result
            </button>

            <button
              type="button"
              onClick={handleGenerateReport}
              disabled={isReportOpening}
              className="flex-1 px-6 py-4 rounded-2xl bg-teal-600 text-white font-bold hover:bg-teal-700 disabled:opacity-60 transition shadow-lg shadow-teal-600/10"
            >
              {isReportOpening ? "Preparing Report..." : "Generate Clinical Report"}
            </button>

            <button
              type="button"
              onClick={handleSendToDoctor}
              className="flex-1 px-6 py-4 rounded-2xl bg-slate-950 text-white font-bold hover:bg-slate-800 transition"
            >
              Send to Ophthalmologist
            </button>
          </div>

          <div className="flex flex-col sm:flex-row justify-between gap-3 mt-4 pb-12">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-3 rounded-xl border border-slate-200 bg-white text-slate-600 font-semibold hover:bg-slate-50 transition"
            >
              ← Back to Analysis
            </button>

            <button
              type="button"
              onClick={onRestart}
              className="px-7 py-3 rounded-xl bg-slate-100 text-slate-800 font-bold hover:bg-slate-200 transition"
            >
              Start New Screening →
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}

/* ============================================================
   SMALL UI COMPONENTS
   ============================================================ */

function SectionHeading({ eyebrow, title, description }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.18em] font-black text-teal-600">
        {eyebrow}
      </p>

      <h3 className="text-2xl font-black tracking-tight mt-2 text-slate-950">
        {title}
      </h3>

      {description ? (
        <p className="text-sm text-slate-500 mt-2 leading-relaxed">
          {description}
        </p>
      ) : null}
    </div>
  );
}

function InfoTile({ label, value, wide = false }) {
  return (
    <div
      className={`rounded-2xl bg-slate-50 border border-slate-200 p-4 ${
        wide ? "col-span-2 lg:col-span-2" : ""
      }`}
    >
      <p className="text-[10px] uppercase tracking-[0.12em] font-bold text-slate-400">
        {label}
      </p>

      <p className="text-sm font-bold text-slate-800 mt-1 break-words">
        {value || "Not provided"}
      </p>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.12em] font-bold text-slate-400">
        {label}
      </p>
      <p className="text-sm font-bold text-slate-800 mt-1 break-words">
        {value || "Not provided"}
      </p>
    </div>
  );
}

function DarkInfoRow({ label, value }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="text-xs text-slate-400 shrink-0">
        {label}
      </span>
      <span className="text-sm font-semibold text-white text-right break-words">
        {value || "Not provided"}
      </span>
    </div>
  );
}

function ImagePanel({
  title,
  subtitle,
  image,
  loading,
  fallback,
}) {
  return (
    <div className="border border-slate-200 rounded-3xl overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-200 bg-slate-50">
        <h4 className="font-bold text-slate-900">
          {title}
        </h4>
        <p className="text-xs text-slate-500 mt-1">
          {subtitle}
        </p>
      </div>

      <div className="min-h-[330px] bg-slate-950 flex items-center justify-center p-5">
        {loading ? (
          <div className="text-center text-slate-400">
            <div className="w-10 h-10 mx-auto rounded-full border-2 border-slate-700 border-t-teal-300 animate-spin" />
            <p className="text-sm mt-4">
              Preparing image...
            </p>
          </div>
        ) : image ? (
          <img
            src={image}
            alt={title}
            className="max-h-[360px] max-w-full object-contain rounded-2xl shadow-2xl"
          />
        ) : (
          <div className="text-center text-slate-500">
            <div className="text-4xl mb-3">◉</div>
            <p className="text-sm">{fallback}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ExplanationCard({ title, text }) {
  return (
    <div className="rounded-2xl bg-slate-50 border border-slate-200 p-5">
      <div className="w-9 h-9 rounded-xl bg-slate-950 text-teal-300 flex items-center justify-center mb-4 font-black">
        ✓
      </div>

      <h4 className="font-bold text-slate-900">
        {title}
      </h4>

      <p className="text-sm text-slate-500 mt-2 leading-relaxed">
        {text}
      </p>
    </div>
  );
}

function ProgressBar() {
  const steps = [
    "Patient",
    "Eye",
    "Capture",
    "Quality",
    "Analysis",
    "Result",
  ];

  return (
    <div className="bg-white border-b border-slate-200 px-4 md:px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center">
        {steps.map((step, index) => {
          const completed = index < 5;
          const active = index === 5;

          return (
            <div
              key={step}
              className="flex items-center flex-1 min-w-0"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black shrink-0 ${
                    completed
                      ? "bg-teal-600 text-white"
                      : active
                      ? "bg-slate-950 text-white ring-4 ring-teal-100"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {completed ? "✓" : index + 1}
                </div>

                <span
                  className={`hidden sm:block text-xs font-bold truncate ${
                    active
                      ? "text-slate-950"
                      : completed
                      ? "text-teal-700"
                      : "text-slate-400"
                  }`}
                >
                  {step}
                </span>
              </div>

              {index < steps.length - 1 ? (
                <div
                  className={`flex-1 h-px mx-2 md:mx-4 ${
                    index < 5
                      ? "bg-teal-200"
                      : "bg-slate-200"
                  }`}
                />
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   FILE → DATA URL
   ============================================================ */

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      resolve(reader.result);
    };

    reader.onerror = () => {
      reject(reader.error);
    };

    reader.readAsDataURL(file);
  });
}

/* ============================================================
   PROTOTYPE GRAD-CAM
   ============================================================ */

function createPrototypeGradCam(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();

    image.onload = () => {
      try {
        const canvas = document.createElement("canvas");

        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;

        const ctx = canvas.getContext("2d");

        if (!ctx) {
          reject(new Error("Canvas is not supported."));
          return;
        }

        ctx.drawImage(
          image,
          0,
          0,
          canvas.width,
          canvas.height
        );

        const centerX = canvas.width * 0.55;
        const centerY = canvas.height * 0.45;

        const radius =
          Math.min(canvas.width, canvas.height) * 0.48;

        const gradient = ctx.createRadialGradient(
          centerX,
          centerY,
          0,
          centerX,
          centerY,
          radius
        );

        gradient.addColorStop(
          0,
          "rgba(255, 0, 0, 0.48)"
        );

        gradient.addColorStop(
          0.2,
          "rgba(255, 165, 0, 0.28)"
        );

        gradient.addColorStop(
          0.48,
          "rgba(255, 165, 0, 0)"
        );

        gradient.addColorStop(
          1,
          "rgba(255, 165, 0, 0)"
        );

        ctx.globalCompositeOperation = "screen";
        ctx.fillStyle = gradient;
        ctx.fillRect(
          0,
          0,
          canvas.width,
          canvas.height
        );

        ctx.globalCompositeOperation = "source-over";

        resolve(canvas.toDataURL("image/png"));
      } catch (error) {
        reject(error);
      }
    };

    image.onerror = () => {
      reject(new Error("Could not load fundus image."));
    };

    image.src = dataUrl;
  });
}

/* ============================================================
   CLINICAL REPORT
   ============================================================ */

function buildClinicalReportHtml({
  patient,
  patientName,
  patientId,
  eyeName,
  clinicName,
  clinicId,
  clinicLocation,
  clinicPhone,
  workerName,
  workerId,
  workerDesignation,
  age,
  sex,
  dob,
  phone,
  address,
  diabetesType,
  diabetesSince,
  treatment,
  hba1c,
  previousDR,
  previousEyeTreatment,
  screeningReason,
  reportId,
  screeningDateTime,
  imageDataUrl,
  gradCamDataUrl,
  aiResult,
}) {
  const escape = escapeHtml;

  return `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>RetinaSafe Clinical Screening Report - ${escape(reportId)}</title>

<style>
  * {
    box-sizing: border-box;
  }

  @page {
    size: A4;
    margin: 12mm;
  }

  body {
    margin: 0;
    background: #e2e8f0;
    color: #0f172a;
    font-family: Arial, Helvetica, sans-serif;
    line-height: 1.45;
  }

  .report {
    width: 210mm;
    max-width: 100%;
    margin: 18px auto;
    background: #ffffff;
    box-shadow: 0 10px 40px rgba(15, 23, 42, 0.14);
  }

  .page {
    min-height: 273mm;
    padding: 18mm;
    position: relative;
    page-break-after: always;
  }

  .page:last-child {
    page-break-after: auto;
  }

  .topline {
    height: 5px;
    background: linear-gradient(90deg, #0f172a, #0d9488);
    margin: -18mm -18mm 18mm;
  }

  .header {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    align-items: flex-start;
    padding-bottom: 16px;
    border-bottom: 1px solid #cbd5e1;
  }

  .brand {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .logo {
    width: 42px;
    height: 42px;
    border-radius: 13px;
    background: #0f172a;
    position: relative;
  }

  .logo-eye {
    position: absolute;
    width: 27px;
    height: 15px;
    border: 2px solid #5eead4;
    border-radius: 50%;
    left: 8px;
    top: 13px;
    transform: rotate(-8deg);
  }

  .logo-pupil {
    position: absolute;
    width: 7px;
    height: 7px;
    background: #5eead4;
    border-radius: 50%;
    left: 18px;
    top: 17px;
  }

  .brand h1 {
    margin: 0;
    font-size: 21px;
    letter-spacing: -0.4px;
  }

  .brand p {
    margin: 2px 0 0;
    color: #64748b;
    font-size: 11px;
  }

  .report-meta {
    text-align: right;
    font-size: 10px;
    color: #64748b;
  }

  .report-meta strong {
    display: block;
    color: #0f172a;
    font-size: 11px;
    margin-top: 3px;
  }

  .clinic-banner {
    margin-top: 16px;
    padding: 13px 15px;
    background: #f0fdfa;
    border: 1px solid #99f6e4;
    border-radius: 10px;
  }

  .clinic-banner .name {
    font-weight: 800;
    color: #134e4a;
    font-size: 14px;
  }

  .clinic-banner .detail {
    color: #0f766e;
    font-size: 10px;
    margin-top: 3px;
  }

  .title {
    margin: 24px 0 20px;
  }

  .title .eyebrow {
    color: #0d9488;
    text-transform: uppercase;
    letter-spacing: 1.8px;
    font-size: 9px;
    font-weight: 800;
  }

  .title h2 {
    font-size: 25px;
    margin: 5px 0;
    letter-spacing: -0.6px;
  }

  .title p {
    color: #64748b;
    margin: 0;
    font-size: 11px;
  }

  .section {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 13px;
    margin-bottom: 12px;
    page-break-inside: avoid;
  }

  .section-title {
    margin: 0 0 10px;
    font-size: 13px;
    color: #0f172a;
  }

  .section-subtitle {
    margin: -5px 0 10px;
    color: #64748b;
    font-size: 9px;
  }

  .grid-2 {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 7px;
  }

  .grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 7px;
  }

  .grid-4 {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 7px;
  }

  .field {
    padding: 8px;
    background: #f8fafc;
    border-radius: 7px;
    border: 1px solid #f1f5f9;
  }

  .field .label {
    color: #64748b;
    font-size: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 700;
  }

  .field .value {
    margin-top: 2px;
    color: #0f172a;
    font-size: 10px;
    font-weight: 700;
    word-break: break-word;
  }

  .status {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    align-items: center;
    padding: 13px;
    border: 1px solid #a7f3d0;
    background: #ecfdf5;
    border-radius: 9px;
  }

  .status .label {
    color: #047857;
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 800;
  }

  .status h3 {
    margin: 3px 0 0;
    color: #064e3b;
    font-size: 18px;
  }

  .confidence {
    text-align: right;
  }

  .confidence .value {
    color: #064e3b;
    font-size: 23px;
    font-weight: 900;
  }

  .confidence .label {
    color: #047857;
    font-size: 8px;
  }

  .bar {
    width: 100%;
    height: 6px;
    margin-top: 6px;
    background: #d1fae5;
    border-radius: 99px;
    overflow: hidden;
  }

  .bar span {
    display: block;
    height: 100%;
    width: ${Math.min(
      100,
      Math.max(0, Number(aiResult.confidence) || 0)
    )}%;
    background: #059669;
  }

  .result-note {
    color: #065f46;
    font-size: 9px;
    margin: 8px 0 0;
  }

  .images {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
  }

  .image-card {
    border: 1px solid #e2e8f0;
    border-radius: 9px;
    overflow: hidden;
  }

  .image-card .heading {
    padding: 9px;
    border-bottom: 1px solid #e2e8f0;
  }

  .image-card h4 {
    margin: 0;
    font-size: 11px;
  }

  .image-card p {
    margin: 2px 0 0;
    color: #64748b;
    font-size: 8px;
  }

  .image-box {
    height: 245px;
    background: #020617;
    padding: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .image-box img {
    max-width: 100%;
    max-height: 225px;
    object-fit: contain;
    border-radius: 5px;
  }

  .evidence {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 7px;
    margin-top: 10px;
  }

  .evidence-card {
    padding: 9px;
    border: 1px solid #e2e8f0;
    background: #f8fafc;
    border-radius: 7px;
  }

  .evidence-card h4 {
    margin: 0;
    font-size: 9px;
  }

  .evidence-card p {
    margin: 4px 0 0;
    color: #64748b;
    font-size: 8px;
  }

  .recommendation {
    padding: 12px;
    border-radius: 9px;
    border: 1px solid #99f6e4;
    background: #f0fdfa;
  }

  .recommendation h3 {
    margin: 0;
    color: #115e59;
    font-size: 15px;
  }

  .recommendation p {
    margin: 5px 0 0;
    color: #134e4a;
    font-size: 9px;
  }

  .warning {
    padding: 10px 12px;
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 8px;
  }

  .warning strong {
    display: block;
    color: #92400e;
    font-size: 9px;
  }

  .warning p {
    margin: 4px 0 0;
    color: #92400e;
    font-size: 8px;
  }

  .review-box {
    min-height: 85px;
    border: 1px dashed #94a3b8;
    border-radius: 8px;
    padding: 10px;
    color: #64748b;
    font-size: 9px;
  }

  .signature-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-top: 25px;
  }

  .signature {
    border-top: 1px solid #475569;
    padding-top: 6px;
    color: #475569;
    font-size: 8px;
  }

  .footer {
    position: absolute;
    left: 18mm;
    right: 18mm;
    bottom: 9mm;
    padding-top: 6px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    color: #94a3b8;
    font-size: 7px;
  }

  .page-number {
    font-weight: 700;
  }

  .small-note {
    color: #64748b;
    font-size: 8px;
    line-height: 1.5;
  }

  @media print {
    body {
      background: #ffffff;
    }

    .report {
      width: auto;
      max-width: none;
      margin: 0;
      box-shadow: none;
    }
  }

  @media (max-width: 800px) {
    body {
      background: #ffffff;
    }

    .report {
      width: 100%;
      margin: 0;
    }

    .page {
      min-height: auto;
      padding: 24px;
    }

    .topline {
      margin: -24px -24px 18px;
    }

    .footer {
      position: static;
      margin-top: 25px;
    }

    .grid-4,
    .grid-3,
    .grid-2,
    .images,
    .evidence,
    .signature-grid {
      grid-template-columns: 1fr;
    }
  }
</style>
</head>

<body>
<div class="report">

  <!-- PAGE 1 -->
  <section class="page">
    <div class="topline"></div>

    <div class="header">
      <div class="brand">
        <div class="logo">
          <div class="logo-eye"></div>
          <div class="logo-pupil"></div>
        </div>
        <div>
          <h1>RetinaSafe</h1>
          <p>Explainable AI-assisted diabetic retinopathy screening</p>
        </div>
      </div>

      <div class="report-meta">
        REPORT ID
        <strong>${escape(reportId)}</strong>
        SCREENING DATE
        <strong>${escape(screeningDateTime.date)}</strong>
      </div>
    </div>

    <div class="clinic-banner">
      <div class="name">${escape(clinicName)}</div>
      <div class="detail">
        Clinic ID: ${escape(clinicId)} &nbsp;•&nbsp;
        ${escape(clinicLocation)} &nbsp;•&nbsp;
        ${escape(clinicPhone)}
      </div>
    </div>

    <div class="title">
      <div class="eyebrow">Clinical screening record</div>
      <h2>Diabetic Retinopathy Screening Report</h2>
      <p>AI-assisted retinal screening summary for clinical review</p>
    </div>

    <div class="section">
      <h3 class="section-title">Patient demographics</h3>

      <div class="grid-4">
        ${reportField("Full name", patientName)}
        ${reportField("Patient ID", patientId)}
        ${reportField("Age", age)}
        ${reportField("Sex", sex)}
        ${reportField("Date of birth", dob)}
        ${reportField("Phone", phone)}
        ${reportField("Eye screened", eyeName)}
        ${reportField("Screening reason", screeningReason)}
      </div>

      <div style="margin-top:7px">
        ${reportField("Address", address)}
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Medical details</h3>

      <div class="grid-3">
        ${reportField("Diabetes type", diabetesType)}
        ${reportField("Diabetes diagnosed since", diabetesSince)}
        ${reportField("HbA1c", hba1c)}
        ${reportField("Treatment", treatment)}
        ${reportField("Previous DR", previousDR)}
        ${reportField("Previous eye treatment", previousEyeTreatment)}
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Screening site & operator</h3>

      <div class="grid-3">
        ${reportField("Clinic / PHC", clinicName)}
        ${reportField("Clinic ID", clinicId)}
        ${reportField("Clinic location", clinicLocation)}
        ${reportField("Screening operator", workerName)}
        ${reportField("Employee ID", workerId)}
        ${reportField("Designation", workerDesignation)}
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">AI screening result</h3>

      <div class="status">
        <div>
          <div class="label">Classification</div>
          <h3>${escape(aiResult.classification)}</h3>
          <p class="result-note">
            No referable diabetic retinopathy detected in the screened image
            according to the current prototype AI output.
          </p>
        </div>

        <div class="confidence">
          <div class="value">${escape(aiResult.confidence)}%</div>
          <div class="label">AI confidence</div>
          <div class="bar">
            <span></span>
          </div>
        </div>
      </div>
    </div>

    <div class="footer">
      <span>RetinaSafe • AI-assisted screening • Human clinical review</span>
      <span class="page-number">Page 1 of 4</span>
    </div>
  </section>

  <!-- PAGE 2 -->
  <section class="page">
    <div class="topline"></div>

    <div class="header">
      <div class="brand">
        <div class="logo">
          <div class="logo-eye"></div>
          <div class="logo-pupil"></div>
        </div>
        <div>
          <h1>RetinaSafe</h1>
          <p>Explainable AI</p>
        </div>
      </div>

      <div class="report-meta">
        REPORT ID
        <strong>${escape(reportId)}</strong>
        EYE
        <strong>${escape(eyeName)}</strong>
      </div>
    </div>

    <div class="title">
      <div class="eyebrow">Explainability</div>
      <h2>AI attention visualization</h2>
      <p>Original retinal image and Grad-CAM evidence for review</p>
    </div>

    <div class="section">
      <div class="images">
        <div class="image-card">
          <div class="heading">
            <h4>Original fundus image</h4>
            <p>${escape(eyeName)}</p>
          </div>

          <div class="image-box">
            <img src="${imageDataUrl}" alt="Original fundus image" />
          </div>
        </div>

        <div class="image-card">
          <div class="heading">
            <h4>Grad-CAM explanation</h4>
            <p>AI attention visualization</p>
          </div>

          <div class="image-box">
            <img src="${gradCamDataUrl}" alt="Grad-CAM visualization" />
          </div>
        </div>
      </div>

      <div class="evidence">
        <div class="evidence-card">
          <h4>Retinal vessels</h4>
          <p>No major vessel abnormalities identified in the current prototype observation.</p>
        </div>

        <div class="evidence-card">
          <h4>Optic disc</h4>
          <p>Optic disc region appears within expected limits in the current prototype observation.</p>
        </div>

        <div class="evidence-card">
          <h4>Lesion regions</h4>
          <p>No prominent lesion pattern identified in the current prototype observation.</p>
        </div>
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Image quality summary</h3>

      <div class="grid-3">
        ${reportField("Focus", "Reviewed by screening pipeline")}
        ${reportField("Illumination", "Reviewed by screening pipeline")}
        ${reportField("Field of view", "Reviewed by screening pipeline")}
      </div>

      <p class="small-note" style="margin:9px 0 0">
        Connect the frontend to the MATLAB quality-check response to replace
        these prototype labels with measured quality values.
      </p>
    </div>

    <div class="warning">
      <strong>Grad-CAM prototype notice</strong>
      <p>
        The heatmap shown in this prototype is generated in the browser for
        visual demonstration. It must be replaced by the actual MATLAB
        generateGradCAM.m output before being treated as model-generated
        explainability evidence.
      </p>
    </div>

    <div class="footer">
      <span>${escape(reportId)} • Explainable AI section</span>
      <span class="page-number">Page 2 of 4</span>
    </div>
  </section>

  <!-- PAGE 3 -->
  <section class="page">
    <div class="topline"></div>

    <div class="header">
      <div class="brand">
        <div class="logo">
          <div class="logo-eye"></div>
          <div class="logo-pupil"></div>
        </div>
        <div>
          <h1>RetinaSafe</h1>
          <p>Clinical findings</p>
        </div>
      </div>

      <div class="report-meta">
        PATIENT
        <strong>${escape(patientName)}</strong>
        EYE
        <strong>${escape(eyeName)}</strong>
      </div>
    </div>

    <div class="title">
      <div class="eyebrow">Clinical findings</div>
      <h2>Structured screening observations</h2>
      <p>Findings prepared for review by a qualified clinician</p>
    </div>

    <div class="section">
      <h3 class="section-title">Retinal observations</h3>
      <p class="section-subtitle">
        Prototype observations displayed from the current frontend result.
      </p>

      <div class="grid-2">
        ${findingField(
          "Retinal vessels",
          "No major vessel abnormalities identified."
        )}
        ${findingField(
          "Optic disc",
          "Optic disc region appears within expected limits."
        )}
        ${findingField(
          "Lesion regions",
          "No prominent lesion pattern identified."
        )}
        ${findingField(
          "Overall screening interpretation",
          "No referable DR in the current prototype result."
        )}
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Screening metadata</h3>

      <div class="grid-3">
        ${reportField("Screening date", screeningDateTime.date)}
        ${reportField("Screening time", screeningDateTime.time)}
        ${reportField("Eye screened", eyeName)}
        ${reportField("Model", aiResult.model)}
        ${reportField("Model version", aiResult.modelVersion)}
        ${reportField("Operator", workerName)}
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Clinical review notes</h3>

      <div class="review-box">
        Ophthalmologist / clinician notes:
        <br /><br />
        ______________________________________________________________________
        <br /><br />
        ______________________________________________________________________
        <br /><br />
        ______________________________________________________________________
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Interpretation</h3>

      <p class="small-note">
        The current prototype indicates a non-referable screening result.
        Interpretation should account for image quality, patient history,
        symptoms and clinical examination. The AI result should not be used
        as a standalone diagnosis.
      </p>
    </div>

    <div class="footer">
      <span>${escape(reportId)} • Clinical findings</span>
      <span class="page-number">Page 3 of 4</span>
    </div>
  </section>

  <!-- PAGE 4 -->
  <section class="page">
    <div class="topline"></div>

    <div class="header">
      <div class="brand">
        <div class="logo">
          <div class="logo-eye"></div>
          <div class="logo-pupil"></div>
        </div>
        <div>
          <h1>RetinaSafe</h1>
          <p>Recommendation & review</p>
        </div>
      </div>

      <div class="report-meta">
        REPORT ID
        <strong>${escape(reportId)}</strong>
        DATE
        <strong>${escape(screeningDateTime.date)}</strong>
      </div>
    </div>

    <div class="title">
      <div class="eyebrow">Recommendation</div>
      <h2>Follow-up & clinical review</h2>
      <p>Recommended next action based on the screening output</p>
    </div>

    <div class="section">
      <h3 class="section-title">Recommended action</h3>

      <div class="recommendation">
        <h3>${escape(aiResult.recommendation)}</h3>
        <p>
          The AI screening indicates no referable diabetic retinopathy in the
          screened image. Continue routine diabetic eye screening according to
          applicable clinical guidance. Clinical escalation remains appropriate
          when symptoms, image-quality concerns or other findings warrant it.
        </p>
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Referral decision</h3>

      <div class="grid-2">
        ${reportField("AI referral status", aiResult.referral)}
        ${reportField("Human review", "Recommended when clinically indicated")}
      </div>
    </div>

    <div class="warning">
      <strong>Important medical disclaimer</strong>
      <p>
        This report contains an AI-assisted screening output and is not a
        definitive medical diagnosis. The result should be interpreted by a
        qualified healthcare professional. Patients with concerning symptoms
        or other clinical findings should receive appropriate medical
        evaluation regardless of the AI result.
      </p>
    </div>

    <div class="section" style="margin-top:12px">
      <h3 class="section-title">Ophthalmologist review</h3>

      <div class="review-box">
        Review status:
        <br /><br />
        ☐ Reviewed & accepted &nbsp;&nbsp;&nbsp;
        ☐ Requires further assessment &nbsp;&nbsp;&nbsp;
        ☐ Referral advised
        <br /><br />
        Notes:
        <br /><br />
        ______________________________________________________________________
      </div>

      <div class="signature-grid">
        <div class="signature">
          PHC / Screening Operator
          <br />
          ${escape(workerName)} • ${escape(workerId)}
        </div>

        <div class="signature">
          Ophthalmologist / Reviewing Clinician
          <br />
          Name, registration number & signature
        </div>
      </div>
    </div>

    <div class="section">
      <h3 class="section-title">Report record</h3>

      <div class="grid-3">
        ${reportField("Report ID", reportId)}
        ${reportField("Generated", screeningDateTime.full)}
        ${reportField("Patient", patientName)}
      </div>
    </div>

    <div class="footer">
      <span>
        RetinaSafe • AI-assisted screening • Human clinical review
      </span>
      <span class="page-number">Page 4 of 4</span>
    </div>
  </section>

</div>

<script>
  window.addEventListener("load", function () {
    setTimeout(function () {
      window.print();
    }, 700);
  });
</script>

</body>
</html>
`;
}

function reportField(label, value) {
  return `
    <div class="field">
      <div class="label">${escapeHtml(label)}</div>
      <div class="value">${escapeHtml(value || "Not provided")}</div>
    </div>
  `;
}

function findingField(label, value) {
  return `
    <div class="field">
      <div class="label">${escapeHtml(label)}</div>
      <div class="value">${escapeHtml(value || "Not available")}</div>
    </div>
  `;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export default ScreeningResult;
