import { useState } from "react";

function QualityCheck({
  selectedEye,
  imageFile,
  onNext,
  onBack,
}) {
  const [checking, setChecking] = useState(false);

  const [quality, setQuality] = useState({
    focus: "good",
    illumination: "good",
    fieldOfView: "adequate",
  });

  const eyeName =
    selectedEye === "left"
      ? "Left Eye"
      : selectedEye === "right"
      ? "Right Eye"
      : "Eye";


  /* ========================================= */
  /* RUN QUALITY CHECK */
  /* ========================================= */

  const runQualityCheck = () => {
    setChecking(true);

    // TEMPORARY PROTOTYPE
    // Later this will call the MATLAB backend:
    // qualityCheck.m

    setTimeout(() => {
      setQuality({
        focus: "good",
        illumination: "good",
        fieldOfView: "adequate",
      });

      setChecking(false);
    }, 1200);
  };


  const isAdequate =
    quality.focus === "good" &&
    quality.illumination === "good" &&
    quality.fieldOfView === "adequate";


  return (
    <div className="min-h-screen bg-slate-50">

      {/* ========================================= */}
      {/* HEADER */}
      {/* ========================================= */}

      <header className="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center">
            <span className="text-xl">
              👁️
            </span>
          </div>

          <div>

            <h1 className="font-bold text-slate-900">
              RetinaSafe
            </h1>

            <p className="text-xs text-slate-500">
              PHC Screening
            </p>

          </div>

        </div>


        <div className="text-sm text-slate-500">
          Step <b className="text-slate-900">4</b> of 6
        </div>

      </header>


      {/* ========================================= */}
      {/* PROGRESS */}
      {/* ========================================= */}

      <ProgressBar active={3} />


      {/* ========================================= */}
      {/* MAIN */}
      {/* ========================================= */}

      <main className="max-w-5xl mx-auto px-6 py-10">

        {/* TITLE */}

        <div className="text-center mb-8">

          <span className="inline-flex px-3 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold">
            STEP 4 · QUALITY
          </span>


          <h2 className="text-4xl font-bold text-slate-900 mt-5">
            Check image quality
          </h2>


          <p className="text-slate-500 mt-3">
            Make sure the retinal image is suitable for AI analysis.
          </p>


          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-slate-200 text-sm text-slate-700">

            <span>
              👁️
            </span>

            {eyeName}

          </div>

        </div>


        {/* ========================================= */}
        {/* IMAGE + QUALITY */}
        {/* ========================================= */}

        <div className="grid lg:grid-cols-2 gap-6">

          {/* IMAGE */}

          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">

            <div className="flex items-center justify-between mb-4">

              <div>

                <h3 className="font-semibold text-slate-900">
                  Fundus Image
                </h3>

                <p className="text-sm text-slate-500 mt-1">
                  {imageFile?.name || "Uploaded image"}
                </p>

              </div>

              <span className="text-xs px-3 py-1.5 rounded-full bg-slate-100 text-slate-600">
                {eyeName}
              </span>

            </div>


            <div className="aspect-square rounded-2xl bg-slate-950 overflow-hidden flex items-center justify-center">

              {imageFile ? (
                <img
                  src={URL.createObjectURL(imageFile)}
                  alt={`${eyeName} fundus`}
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-slate-400 text-center">
                  <div className="text-5xl mb-3">
                    📷
                  </div>

                  <p>
                    No image available
                  </p>
                </div>
              )}

            </div>

          </div>


          {/* QUALITY PANEL */}

          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">

            <h3 className="text-xl font-semibold text-slate-900">
              Image Quality Assessment
            </h3>


            <p className="text-sm text-slate-500 mt-2">
              The system checks three important image properties.
            </p>


            <div className="mt-7 space-y-4">

              <QualityRow
                title="Focus"
                description="Checks whether retinal structures are sharp."
                status={quality.focus === "good" ? "Good" : "Poor"}
              />


              <QualityRow
                title="Illumination"
                description="Checks whether brightness is suitable."
                status={
                  quality.illumination === "good"
                    ? "Good"
                    : "Poor"
                }
              />


              <QualityRow
                title="Field of View"
                description="Checks whether enough retina is visible."
                status={
                  quality.fieldOfView === "adequate"
                    ? "Adequate"
                    : "Inadequate"
                }
              />

            </div>


            {/* CHECK BUTTON */}

            <button
              type="button"
              onClick={runQualityCheck}
              disabled={checking}
              className="w-full mt-7 px-6 py-3.5 rounded-xl bg-slate-950 text-white font-semibold hover:bg-slate-800 disabled:opacity-60 transition"
            >
              {checking
                ? "Checking image..."
                : "Run Quality Check"}
            </button>


            {/* RESULT */}

            {!checking && (
              <div
                className={`mt-5 p-4 rounded-2xl border ${
                  isAdequate
                    ? "bg-emerald-50 border-emerald-200"
                    : "bg-red-50 border-red-200"
                }`}
              >

                <div className="flex items-start gap-3">

                  <div className="text-xl">
                    {isAdequate ? "✓" : "⚠️"}
                  </div>

                  <div>

                    <p
                      className={`font-semibold ${
                        isAdequate
                          ? "text-emerald-800"
                          : "text-red-800"
                      }`}
                    >
                      {isAdequate
                        ? "Image suitable for analysis"
                        : "Image quality insufficient"}
                    </p>


                    <p
                      className={`text-sm mt-1 ${
                        isAdequate
                          ? "text-emerald-700"
                          : "text-red-700"
                      }`}
                    >
                      {isAdequate
                        ? "The image can proceed to AI screening."
                        : "Please capture another retinal image."}
                    </p>

                  </div>

                </div>

              </div>
            )}

          </div>

        </div>


        {/* ========================================= */}
        {/* NAVIGATION */}
        {/* ========================================= */}

        <div className="flex items-center justify-between mt-8">

          <button
            type="button"
            onClick={onBack}
            className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 transition"
          >
            ← Back
          </button>


          <button
            type="button"
            disabled={!isAdequate || checking}
            onClick={onNext}
            className={`px-7 py-3 rounded-xl font-semibold transition ${
              isAdequate && !checking
                ? "bg-slate-950 text-white hover:bg-slate-800"
                : "bg-slate-200 text-slate-400 cursor-not-allowed"
            }`}
          >
            Continue to Analysis →
          </button>

        </div>

      </main>

    </div>
  );
}


/* ================================================= */
/* QUALITY ROW */
/* ================================================= */

function QualityRow({
  title,
  description,
  status,
}) {

  const good =
    status === "Good" ||
    status === "Adequate";


  return (
    <div className="flex items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">

      <div>

        <h4 className="font-semibold text-slate-900">
          {title}
        </h4>

        <p className="text-xs text-slate-500 mt-1">
          {description}
        </p>

      </div>


      <div
        className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold ${
          good
            ? "bg-emerald-100 text-emerald-700"
            : "bg-red-100 text-red-700"
        }`}
      >
        {good ? "✓ " : "⚠ "}
        {status}
      </div>

    </div>
  );
}


/* ================================================= */
/* PROGRESS BAR */
/* ================================================= */

function ProgressBar({ active }) {

  const steps = [
    "Patient",
    "Eye",
    "Capture",
    "Quality",
    "Analysis",
    "Result",
  ];


  return (
    <div className="bg-white border-b border-slate-200 px-6 py-5">

      <div className="max-w-5xl mx-auto flex items-center">

        {steps.map((step, index) => (

          <div
            key={step}
            className="flex items-center flex-1"
          >

            <div className="flex items-center gap-2">

              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  index <= active
                    ? "bg-slate-950 text-white"
                    : "bg-slate-100 text-slate-400"
                }`}
              >
                {index + 1}
              </div>


              <span
                className={`hidden sm:block text-xs font-semibold ${
                  index <= active
                    ? "text-slate-900"
                    : "text-slate-400"
                }`}
              >
                {step}
              </span>

            </div>


            {index < steps.length - 1 && (
              <div className="flex-1 h-px bg-slate-200 mx-3" />
            )}

          </div>

        ))}

      </div>

    </div>
  );
}


export default QualityCheck;