import { useEffect, useState } from "react";

import EyeSelection from "./pages/phc/EyeSelection";
import CaptureImage from "./pages/phc/CaptureImage";
import QualityCheck from "./pages/phc/QualityCheck";
import AIAnalysis from "./pages/phc/AIAnalysis";
import ScreeningResult from "./pages/phc/ScreeningResult";
import DoctorDashboard from "./pages/doctor/DoctorDashboard";
import DoctorCaseReview from "./pages/doctor/DoctorCaseReview";
import ClinicalReport from "./pages/doctor/ClinicalReport";


/* =========================================================
   APP
   ========================================================= */

function App() {
  /* =========================================================
     GLOBAL STATE
     ========================================================= */

  const [role, setRole] = useState(null);
  const [doctorView, setDoctorView] = useState("dashboard");
  const [selectedCase, setSelectedCase] = useState(null);
  const [doctorReview, setDoctorReview] = useState(null);

  /*
    PHC workflow:

    patient
      ↓
    eye
      ↓
    capture
      ↓
    quality
      ↓
    analysis
      ↓
    result
  */

  const [phcStage, setPhcStage] = useState("patient");


  /* =========================================================
     PATIENT + SCREENING INFORMATION
     ========================================================= */

  const [patient, setPatient] = useState({
    /* -------------------------
       Clinic / PHC
    ------------------------- */

    clinicName: "",
    clinicId: "",
    clinicLocation: "",
    clinicPhone: "",


    /* -------------------------
       Patient identity
    ------------------------- */

    patientId: "",
    fullName: "",
    dob: "",
    age: "",
    sex: "",
    phone: "",
    address: "",
    village: "",
    district: "",
    state: "",


    /* -------------------------
       Diabetes history
    ------------------------- */

    diabetesType: "",
    diabetesSince: "",
    treatment: "",
    hba1c: "",
    previousDR: "",
    previousEyeTreatment: "",


    /* -------------------------
       Screening information
    ------------------------- */

    screeningReason: "",


    /* -------------------------
       PHC worker
    ------------------------- */

    workerName: "",
    workerId: "",
    workerDesignation: "",
  });


  /* =========================================================
     SCREENING STATE
     ========================================================= */

  const [selectedEye, setSelectedEye] = useState("");

  const [imageFile, setImageFile] = useState(null);


  /* =========================================================
     SAFE STAGE FALLBACK
     ========================================================= */

  useEffect(() => {
    const validStages = [
      "patient",
      "eye",
      "capture",
      "quality",
      "analysis",
      "result",
    ];

    if (!validStages.includes(phcStage)) {
      setPhcStage("patient");
    }
  }, [phcStage]);


  /* =========================================================
     ROLE SELECTION
     ========================================================= */

  if (!role) {
    return (
      <RoleSelection
        onSelectRole={(selectedRole) => {
          setRole(selectedRole);

          if (selectedRole === "phc") {
            setPhcStage("patient");
          }

          if (selectedRole === "doctor") {
            setDoctorView("dashboard");
            setSelectedCase(null);
          }
        }}
      />
    );
  }


  /* =========================================================
     PHC WORKFLOW
     ========================================================= */

  if (role === "phc") {

    /* =======================================================
       STEP 1 — PATIENT REGISTRATION
       ======================================================= */

    if (phcStage === "patient") {
      return (
        <PatientScreen
          patient={patient}
          setPatient={setPatient}

          onNext={() => {
            setPhcStage("eye");
          }}

          onBack={() => {
            setRole(null);
          }}
        />
      );
    }


    /* =======================================================
       STEP 2 — EYE SELECTION
       ======================================================= */

    if (phcStage === "eye") {
      return (
        <EyeSelection
          selectedEye={selectedEye}
          setSelectedEye={setSelectedEye}

          onNext={() => {
            setPhcStage("capture");
          }}

          onBack={() => {
            setPhcStage("patient");
          }}
        />
      );
    }


    /* =======================================================
       STEP 3 — FUNDUS CAPTURE
       ======================================================= */

    if (phcStage === "capture") {
      return (
        <CaptureImage
          selectedEye={selectedEye}
          imageFile={imageFile}
          setImageFile={setImageFile}

          onNext={() => {
            setPhcStage("quality");
          }}

          onBack={() => {
            setPhcStage("eye");
          }}
        />
      );
    }


    /* =======================================================
       STEP 4 — IMAGE QUALITY
       ======================================================= */

    if (phcStage === "quality") {
      return (
        <QualityCheck
          selectedEye={selectedEye}
          imageFile={imageFile}

          onNext={() => {
            setPhcStage("analysis");
          }}

          onBack={() => {
            setPhcStage("capture");
          }}
        />
      );
    }


    /* =======================================================
       STEP 5 — AI ANALYSIS
       ======================================================= */

    if (phcStage === "analysis") {
      return (
        <AIAnalysis
          selectedEye={selectedEye}
          imageFile={imageFile}

          onNext={() => {
            setPhcStage("result");
          }}

          onBack={() => {
            setPhcStage("quality");
          }}
        />
      );
    }


    /* =======================================================
       STEP 6 — SCREENING RESULT
       ======================================================= */

    if (phcStage === "result") {
      return (
        <ScreeningResult
          patient={patient}
          selectedEye={selectedEye}
          imageFile={imageFile}

          onBack={() => {
            setPhcStage("analysis");
          }}

          onRestart={() => {

            setPatient({
              /* Clinic / PHC */
              clinicName: "",
              clinicId: "",
              clinicLocation: "",
              clinicPhone: "",

              /* Patient identity */
              patientId: "",
              fullName: "",
              dob: "",
              age: "",
              sex: "",
              phone: "",
              address: "",
              village: "",
              district: "",
              state: "",

              /* Diabetes */
              diabetesType: "",
              diabetesSince: "",
              treatment: "",
              hba1c: "",
              previousDR: "",
              previousEyeTreatment: "",

              /* Screening */
              screeningReason: "",

              /* PHC worker */
              workerName: "",
              workerId: "",
              workerDesignation: "",
            });

            setSelectedEye("");

            setImageFile(null);

            setPhcStage("patient");
          }}
        />
      );
    }


    /* =======================================================
       FALLBACK
       ======================================================= */

    return null;
  }


  /* =========================================================
     OPHTHALMOLOGIST
     ========================================================= */

  if (role === "doctor") {
    if (doctorView === "report" && selectedCase) {
      return (
        <ClinicalReport
          caseData={selectedCase}
          review={doctorReview}
          onBack={() => setDoctorView("review")}
          onDashboard={() => {
            setDoctorReview(null);
            setSelectedCase(null);
            setDoctorView("dashboard");
          }}
        />
      );
    }

    if (doctorView === "review" && selectedCase) {
      return (
        <DoctorCaseReview
          caseData={selectedCase}
          onBack={() => {
            setSelectedCase(null);
            setDoctorReview(null);
            setDoctorView("dashboard");
          }}
          onGenerateReport={(reviewData) => {
            setDoctorReview(reviewData);
            setDoctorView("report");
          }}
        />
      );
    }

    return (
      <DoctorDashboard
        onReviewCase={(caseData) => {
          setSelectedCase(caseData);
          setDoctorView("review");
        }}
        onBack={() => {
          setSelectedCase(null);
          setDoctorView("dashboard");
          setRole(null);
        }}
      />
    );
  }


  return null;
}


/* =========================================================
   ROLE SELECTION
   ========================================================= */

function RoleSelection({ onSelectRole }) {
  return (
    <main className="min-h-screen bg-[#07151a] text-white relative overflow-hidden flex items-center justify-center px-6 py-12">

      {/* Background atmosphere */}

      <div className="absolute -top-40 -left-40 w-[500px] h-[500px] rounded-full bg-teal-500/10 blur-3xl" />

      <div className="absolute -bottom-40 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-500/10 blur-3xl" />


      {/* Main */}

      <div className="relative z-10 w-full max-w-6xl">

        {/* BRAND */}

        <div className="text-center mb-14 step-enter">

          <div className="flex justify-center mb-6">

            <div className="role-eye-container">

              <div className="role-eye">

                <div className="role-eye-pupil" />

              </div>

            </div>

          </div>


          <p className="text-xs uppercase tracking-[0.3em] text-teal-300 font-bold">
            Intelligent retinal screening
          </p>


          <h1 className="text-5xl sm:text-6xl font-bold tracking-tight mt-3">
            Retina<span className="text-teal-400">Safe</span>
          </h1>


          <p className="mt-5 text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Explainable AI-assisted diabetic retinopathy screening
            designed for connected rural healthcare.
          </p>

        </div>


        {/* ROLE HEADING */}

        <div className="text-center mb-8">

          <p className="text-sm text-slate-500">
            Secure clinical workspace
          </p>

          <h2 className="text-2xl sm:text-3xl font-bold mt-2">
            Select your role
          </h2>

        </div>


        {/* ROLE CARDS */}

        <div className="grid md:grid-cols-2 gap-6">


          {/* PHC */}

          <button
            type="button"
            onClick={() => onSelectRole("phc")}
            className="group text-left rounded-[28px] border border-white/10 bg-white/[0.045] backdrop-blur-xl p-8 sm:p-10 hover:bg-white/[0.08] hover:border-teal-400/30 transition-all duration-500 hover:-translate-y-1"
          >

            <div className="flex items-start justify-between">

              <div className="role-card-icon">
                +
              </div>

              <span className="text-xs font-semibold text-slate-500 group-hover:text-teal-300 transition-colors">
                WORKSPACE 01
              </span>

            </div>


            <h3 className="text-2xl font-bold mt-8">
              PHC Worker
            </h3>


            <p className="mt-3 text-slate-400 leading-relaxed">
              Register patients, capture fundus images and perform
              AI-assisted retinal screening at the primary health centre.
            </p>


            <div className="mt-8 flex items-center gap-3 text-teal-300 font-semibold">

              <span>
                Start screening
              </span>

              <span className="transition-transform duration-300 group-hover:translate-x-2">
                →
              </span>

            </div>

          </button>


          {/* OPHTHALMOLOGIST */}

          <button
            type="button"
            onClick={() => onSelectRole("doctor")}
            className="group text-left rounded-[28px] border border-white/10 bg-white/[0.045] backdrop-blur-xl p-8 sm:p-10 hover:bg-white/[0.08] hover:border-cyan-400/30 transition-all duration-500 hover:-translate-y-1"
          >

            <div className="flex items-start justify-between">

              <div className="role-card-icon">
                ◉
              </div>

              <span className="text-xs font-semibold text-slate-500 group-hover:text-cyan-300 transition-colors">
                WORKSPACE 02
              </span>

            </div>


            <h3 className="text-2xl font-bold mt-8">
              Ophthalmologist
            </h3>


            <p className="mt-3 text-slate-400 leading-relaxed">
              Review screening cases, inspect AI explanations and
              make the final clinical decision.
            </p>


            <div className="mt-8 flex items-center gap-3 text-cyan-300 font-semibold">

              <span>
                Review cases
              </span>

              <span className="transition-transform duration-300 group-hover:translate-x-2">
                →
              </span>

            </div>

          </button>

        </div>


        {/* FOOTER */}

        <div className="text-center mt-10">

          <p className="text-xs text-slate-600">
            AI-assisted screening • Human clinical review
          </p>

        </div>

      </div>

    </main>
  );
}


/* =========================================================
   PATIENT SCREEN
   ========================================================= */

function PatientScreen({
  patient,
  setPatient,
  onNext,
  onBack,
}) {

  const [section, setSection] = useState(0);


  /* =======================================================
     SECTION DATA
     ======================================================= */

  const sectionTitles = [
    "Patient identity",
    "Diabetes history",
    "PHC & screening",
  ];


  const sectionDescriptions = [
    "Enter the patient's identifying information. These details will be included in the screening record.",
    "Capture the patient's diabetes history to provide clinical context for retinal screening.",
    "Record the healthcare worker and clinic responsible for this screening. These details will appear in the final clinical report.",
  ];


  /* =======================================================
     UPDATE PATIENT
     ======================================================= */

  const updatePatient = (field, value) => {
    setPatient((previous) => ({
      ...previous,
      [field]: value,
    }));
  };


  /* =======================================================
     VALIDATION
     ======================================================= */

  const canContinue = () => {

    /* Section 1 */

    if (section === 0) {
      return (
        patient.fullName.trim() !== "" &&
        patient.patientId.trim() !== "" &&
        patient.age !== "" &&
        patient.sex !== ""
      );
    }


    /* Section 2 */

    if (section === 1) {
      return patient.diabetesType !== "";
    }


    /* Section 3 */

    if (section === 2) {
      return (
        patient.workerName.trim() !== "" &&
        patient.workerId.trim() !== "" &&
        patient.clinicName.trim() !== ""
      );
    }


    return false;
  };


  /* =======================================================
     NEXT
     ======================================================= */

  const handleNext = () => {

    if (!canContinue()) {
      return;
    }


    if (section < 2) {
      setSection((previous) => previous + 1);
    } else {
      onNext();
    }
  };


  /* =======================================================
     RENDER
     ======================================================= */

  return (
    <div className="min-h-screen bg-[#f4f8f8] text-slate-900 relative overflow-hidden">


      {/* ===================================================
          AMBIENT BACKGROUND
      =================================================== */}

      <div className="absolute top-0 left-0 w-[520px] h-[520px] bg-teal-200/20 rounded-full blur-3xl pointer-events-none" />

      <div className="absolute bottom-0 right-0 w-[520px] h-[520px] bg-cyan-200/20 rounded-full blur-3xl pointer-events-none" />


      {/* ===================================================
          HEADER
      =================================================== */}

      <header className="relative z-10 bg-white/90 backdrop-blur-xl border-b border-slate-200">

        <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 h-[76px] flex items-center justify-between">


          {/* BRAND */}

          <div className="flex items-center gap-3">

            <div className="eye-logo-small">

              <div className="eye-shape-small">

                <div className="eye-pupil-small" />

              </div>

            </div>


            <div>

              <h1 className="text-xl font-bold tracking-tight text-slate-950">
                RetinaSafe
              </h1>

              <p className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">
                PHC Screening
              </p>

            </div>

          </div>


          {/* WORKSTATION STATUS */}

          <div className="flex items-center gap-4">


            <div className="hidden sm:block text-right">

              <p className="text-[11px] text-slate-400">
                Screening workstation
              </p>

              <p className="text-sm font-bold text-slate-700">
                PHC-024
              </p>

            </div>


            <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-emerald-50 border border-emerald-100">

              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />

              <span className="text-xs font-bold text-emerald-700">
                System ready
              </span>

            </div>

          </div>

        </div>

      </header>


      {/* ===================================================
          GLOBAL SCREENING PROGRESS
      =================================================== */}

      <div className="relative z-10 bg-white/80 backdrop-blur-md border-b border-slate-200">

        <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 py-5">


          <div className="flex items-center justify-between mb-5">

            <div>

              <p className="text-[10px] uppercase tracking-[0.2em] text-teal-600 font-bold">
                Screening workflow
              </p>

              <p className="text-xs text-slate-400 mt-1">
                Patient registration
              </p>

            </div>


            <div className="text-right">

              <p className="text-xs text-slate-400">
                Progress
              </p>

              <p className="text-sm font-bold text-slate-800">
                01 <span className="text-slate-300">/ 06</span>
              </p>

            </div>

          </div>


          <ProgressBar active={0} />

        </div>

      </div>


      {/* ===================================================
          MAIN
      =================================================== */}

      <main className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 py-10 lg:py-14">


        <div className="grid lg:grid-cols-[minmax(0,1fr)_350px] gap-10 xl:gap-14 items-start">


          {/* =================================================
              LEFT CONTENT
          ================================================= */}

          <div>


            {/* INTRO */}

            <div className="step-enter">

              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-50 border border-teal-100 text-teal-700 text-[11px] font-bold">

                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />

                STEP 01 · PATIENT

              </div>


              <h2 className="text-4xl sm:text-5xl xl:text-[54px] leading-[1.05] font-bold tracking-tight mt-5 text-slate-950">

                Let's start with
                <br />

                <span className="text-teal-600">
                  the patient.
                </span>

              </h2>


              <p className="mt-5 text-slate-500 text-base sm:text-lg leading-relaxed max-w-2xl">

                Enter the information carefully. The details collected here
                will follow the patient through image analysis and appear in
                the final clinical screening report.

              </p>

            </div>


            {/* =================================================
                FORM CARD
            ================================================= */}

            <div className="mt-10 bg-white/95 backdrop-blur-xl rounded-[28px] border border-slate-200 shadow-[0_24px_80px_rgba(15,23,42,0.08)] overflow-hidden">


              {/* FORM HEADER */}

              <div className="px-6 sm:px-9 py-6 border-b border-slate-100">

                <div className="flex items-center justify-between gap-5">

                  <div>

                    <p className="text-[10px] uppercase tracking-[0.18em] text-slate-400 font-bold">
                      Registration section
                    </p>

                    <h3 className="text-xl font-bold mt-1 text-slate-950">
                      {sectionTitles[section]}
                    </h3>

                  </div>


                  <div className="text-right shrink-0">

                    <p className="text-[10px] uppercase tracking-widest text-slate-400">
                      Section
                    </p>

                    <p className="text-lg font-bold text-teal-600">
                      0{section + 1}
                      <span className="text-slate-300">
                        {" "} / 03
                      </span>
                    </p>

                  </div>

                </div>


                {/* SECTION PROGRESS */}

                <div className="flex gap-1.5 mt-5">

                  {[0, 1, 2].map((item) => (

                    <div
                      key={item}
                      className={`h-1 rounded-full flex-1 transition-all duration-700 ${
                        item <= section
                          ? "bg-teal-500"
                          : "bg-slate-100"
                      }`}
                    />

                  ))}

                </div>

              </div>


              {/* =================================================
                  FORM CONTENT
              ================================================= */}

              <div className="p-6 sm:p-9">


                <p className="text-sm text-slate-500 mb-8 leading-relaxed">
                  {sectionDescriptions[section]}
                </p>


                {/* =================================================
                    SECTION 1 — PATIENT IDENTITY
                ================================================= */}

                {section === 0 && (

                  <div
                    key="identity"
                    className="form-section-enter space-y-6"
                  >

                    <AnimatedField
                      number="01"
                      label="Full name"
                      required
                      value={patient.fullName}
                      placeholder="Enter patient's full name"
                      onChange={(value) =>
                        updatePatient("fullName", value)
                      }
                    />


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="02"
                        label="Patient ID / UHID"
                        required
                        value={patient.patientId}
                        placeholder="e.g. RS-2026-00124"
                        onChange={(value) =>
                          updatePatient("patientId", value)
                        }
                      />


                      <AnimatedField
                        number="03"
                        label="Date of birth"
                        type="date"
                        value={patient.dob}
                        onChange={(value) =>
                          updatePatient("dob", value)
                        }
                      />

                    </div>


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="04"
                        label="Age"
                        required
                        type="number"
                        value={patient.age}
                        placeholder="Age in years"
                        onChange={(value) =>
                          updatePatient("age", value)
                        }
                      />


                      <AnimatedSelect
                        number="05"
                        label="Sex"
                        required
                        value={patient.sex}
                        onChange={(value) =>
                          updatePatient("sex", value)
                        }
                        options={[
                          ["", "Select sex"],
                          ["female", "Female"],
                          ["male", "Male"],
                          ["other", "Other"],
                        ]}
                      />

                    </div>


                    <AnimatedField
                      number="06"
                      label="Phone number"
                      type="tel"
                      value={patient.phone}
                      placeholder="10-digit mobile number"
                      onChange={(value) =>
                        updatePatient("phone", value)
                      }
                    />


                    <AnimatedField
                      number="07"
                      label="Address"
                      value={patient.address}
                      placeholder="House number / street / locality"
                      onChange={(value) =>
                        updatePatient("address", value)
                      }
                    />


                    <div className="grid sm:grid-cols-3 gap-5">

                      <AnimatedField
                        number="08"
                        label="Village / locality"
                        value={patient.village}
                        placeholder="Village"
                        onChange={(value) =>
                          updatePatient("village", value)
                        }
                      />


                      <AnimatedField
                        number="09"
                        label="District"
                        value={patient.district}
                        placeholder="District"
                        onChange={(value) =>
                          updatePatient("district", value)
                        }
                      />


                      <AnimatedField
                        number="10"
                        label="State"
                        value={patient.state}
                        placeholder="State"
                        onChange={(value) =>
                          updatePatient("state", value)
                        }
                      />

                    </div>

                  </div>
                )}


                {/* =================================================
                    SECTION 2 — DIABETES
                ================================================= */}

                {section === 1 && (

                  <div
                    key="diabetes"
                    className="form-section-enter space-y-6"
                  >

                    <AnimatedSelect
                      number="01"
                      label="Diabetes type"
                      required
                      value={patient.diabetesType}
                      onChange={(value) =>
                        updatePatient("diabetesType", value)
                      }
                      options={[
                        ["", "Select diabetes type"],
                        ["type1", "Type 1 diabetes"],
                        ["type2", "Type 2 diabetes"],
                        ["gestational", "Gestational diabetes"],
                        ["other", "Other / unspecified"],
                      ]}
                    />


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="02"
                        label="Year diagnosed"
                        type="number"
                        value={patient.diabetesSince}
                        placeholder="e.g. 2018"
                        onChange={(value) =>
                          updatePatient("diabetesSince", value)
                        }
                      />


                      <AnimatedField
                        number="03"
                        label="Latest HbA1c"
                        value={patient.hba1c}
                        placeholder="e.g. 7.2 %"
                        onChange={(value) =>
                          updatePatient("hba1c", value)
                        }
                      />

                    </div>


                    <AnimatedField
                      number="04"
                      label="Current diabetes treatment"
                      value={patient.treatment}
                      placeholder="e.g. Metformin / Insulin / Other"
                      onChange={(value) =>
                        updatePatient("treatment", value)
                      }
                    />


                    <ChoiceField
                      number="05"
                      label="Previous diabetic retinopathy?"
                      value={patient.previousDR}
                      onChange={(value) =>
                        updatePatient("previousDR", value)
                      }
                      options={[
                        ["yes", "Yes"],
                        ["no", "No"],
                        ["unknown", "Unknown"],
                      ]}
                    />


                    <ChoiceField
                      number="06"
                      label="Previous eye treatment?"
                      value={patient.previousEyeTreatment}
                      onChange={(value) =>
                        updatePatient("previousEyeTreatment", value)
                      }
                      options={[
                        ["yes", "Yes"],
                        ["no", "No"],
                        ["unknown", "Unknown"],
                      ]}
                    />

                  </div>
                )}


                {/* =================================================
                    SECTION 3 — PHC
                ================================================= */}

                {section === 2 && (

                  <div
                    key="phc"
                    className="form-section-enter space-y-6"
                  >


                    {/* PHC INFO CARD */}

                    <div className="rounded-2xl bg-teal-50 border border-teal-100 p-5 mb-7">

                      <div className="flex gap-4">

                        <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                          PHC
                        </div>


                        <div>

                          <h4 className="font-bold text-teal-950">
                            Screening operator & clinic details
                          </h4>

                          <p className="text-sm text-teal-800/70 mt-1 leading-relaxed">
                            Record who performed the screening and where it
                            was conducted. These details will appear in the
                            final clinical report.
                          </p>

                        </div>

                      </div>

                    </div>


                    <AnimatedField
                      number="01"
                      label="PHC worker full name"
                      required
                      value={patient.workerName}
                      placeholder="Enter health worker's full name"
                      onChange={(value) =>
                        updatePatient("workerName", value)
                      }
                    />


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="02"
                        label="Worker ID"
                        required
                        value={patient.workerId}
                        placeholder="e.g. HW-024"
                        onChange={(value) =>
                          updatePatient("workerId", value)
                        }
                      />


                      <AnimatedSelect
                        number="03"
                        label="Designation"
                        value={patient.workerDesignation}
                        onChange={(value) =>
                          updatePatient("workerDesignation", value)
                        }
                        options={[
                          ["", "Select designation"],
                          ["asha", "ASHA Worker"],
                          ["anm", "ANM"],
                          ["phc_staff", "PHC Staff"],
                          ["technician", "Screening Technician"],
                          ["other", "Other"],
                        ]}
                      />

                    </div>


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="04"
                        label="Clinic / PHC name"
                        required
                        value={patient.clinicName}
                        placeholder="Primary Health Centre"
                        onChange={(value) =>
                          updatePatient("clinicName", value)
                        }
                      />


                      <AnimatedField
                        number="05"
                        label="Clinic / PHC ID"
                        value={patient.clinicId}
                        placeholder="e.g. PHC-024"
                        onChange={(value) =>
                          updatePatient("clinicId", value)
                        }
                      />

                    </div>


                    <div className="grid sm:grid-cols-2 gap-5">

                      <AnimatedField
                        number="06"
                        label="Clinic phone"
                        type="tel"
                        value={patient.clinicPhone}
                        placeholder="Clinic contact number"
                        onChange={(value) =>
                          updatePatient("clinicPhone", value)
                        }
                      />


                      <AnimatedField
                        number="07"
                        label="Clinic location"
                        value={patient.clinicLocation}
                        placeholder="Village / district / location"
                        onChange={(value) =>
                          updatePatient("clinicLocation", value)
                        }
                      />

                    </div>


                    <AnimatedSelect
                      number="06"
                      label="Reason for screening"
                      value={patient.screeningReason}
                      onChange={(value) =>
                        updatePatient("screeningReason", value)
                      }
                      options={[
                        ["", "Select screening reason"],
                        ["routine", "Routine diabetic screening"],
                        ["followup", "Follow-up screening"],
                        ["symptoms", "Eye symptoms / concern"],
                        [
                          "referral",
                          "Referral from healthcare provider",
                        ],
                      ]}
                    />

                  </div>
                )}

              </div>


              {/* =================================================
                  FORM FOOTER
              ================================================= */}

              <div className="px-6 sm:px-9 py-5 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between gap-4">


                <button
                  type="button"
                  onClick={() => {

                    if (section > 0) {
                      setSection((previous) => previous - 1);
                    } else {
                      onBack();
                    }

                  }}
                  className="px-5 py-3 rounded-xl border border-slate-200 bg-white text-slate-600 font-semibold hover:border-slate-300 hover:bg-slate-50 transition-all duration-300"
                >
                  ← Back
                </button>


                <div className="flex items-center gap-3">

                  <span className="hidden sm:block text-xs text-slate-400">
                    {section === 2
                      ? "Ready for eye selection"
                      : "Next section"}
                  </span>


                  <button
                    type="button"
                    onClick={handleNext}
                    disabled={!canContinue()}
                    className={`px-6 sm:px-7 py-3 rounded-xl font-bold transition-all duration-300 ${
                      canContinue()
                        ? "bg-slate-950 text-white hover:bg-teal-700 hover:-translate-y-0.5 shadow-lg shadow-slate-900/10"
                        : "bg-slate-200 text-slate-400 cursor-not-allowed"
                    }`}
                  >
                    {section === 2
                      ? "Continue to Eye Selection →"
                      : "Continue →"}
                  </button>

                </div>

              </div>

            </div>

          </div>


          {/* =================================================
              RIGHT SIDE INFORMATION PANEL
          ================================================= */}

          <aside className="hidden lg:block lg:sticky lg:top-8">


            <div className="bg-[#071b20] rounded-[28px] p-7 text-white shadow-2xl overflow-hidden relative">


              {/* Decorative circles */}

              <div className="absolute -right-20 -top-20 w-48 h-48 rounded-full bg-teal-400/10 blur-2xl" />

              <div className="absolute -left-20 bottom-0 w-40 h-40 rounded-full bg-cyan-400/10 blur-2xl" />


              <div className="relative">


                {/* EYE */}

                <div className="flex items-center gap-4">

                  <div className="eye-animation-card">

                    <div className="eye-card-shape">

                      <div className="eye-card-pupil" />

                    </div>

                  </div>


                  <div>

                    <p className="text-[10px] text-teal-300 uppercase tracking-[0.2em] font-bold">
                      RetinaSafe
                    </p>

                    <p className="font-semibold mt-1">
                      Guided screening
                    </p>

                  </div>

                </div>


                {/* DESCRIPTION */}

                <p className="text-sm text-slate-400 leading-relaxed mt-8">

                  The registration process is divided into focused sections
                  so the screening operator can enter information naturally
                  without navigating a long clinical form.

                </p>


                {/* SECTIONS */}

                <div className="mt-8 space-y-2">

                  {sectionTitles.map((title, index) => (

                    <div
                      key={title}
                      className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-500 ${
                        index === section
                          ? "bg-white/10"
                          : ""
                      }`}
                    >

                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-500 ${
                          index < section
                            ? "bg-teal-500 text-white"
                            : index === section
                              ? "bg-white text-slate-950"
                              : "bg-white/10 text-slate-500"
                        }`}
                      >
                        {index < section
                          ? "✓"
                          : index + 1}
                      </div>


                      <span
                        className={`text-sm transition-colors duration-300 ${
                          index === section
                            ? "text-white font-semibold"
                            : "text-slate-500"
                        }`}
                      >
                        {title}
                      </span>

                    </div>

                  ))}

                </div>


                {/* WORKFLOW */}

                <div className="mt-8 pt-6 border-t border-white/10">

                  <p className="text-[10px] uppercase tracking-[0.2em] text-slate-600 font-bold">
                    Clinical workflow
                  </p>

                  <p className="text-sm text-slate-300 mt-2">
                    Patient → Eye → Capture → Quality → AI → Result
                  </p>

                </div>


                {/* SECURITY */}

                <div className="mt-6 flex items-center gap-2 text-xs text-slate-500">

                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />

                  Screening data ready for secure processing

                </div>

              </div>

            </div>

          </aside>

        </div>

      </main>

    </div>
  );
}


/* =========================================================
   ANIMATED FIELD
   ========================================================= */

function AnimatedField({
  number,
  label,
  value,
  placeholder,
  type = "text",
  required = false,
  onChange,
}) {
  return (
    <div className="field-enter">

      <div className="flex items-center justify-between mb-2">

        <label className="text-sm font-semibold text-slate-800">

          {label}

          {required && (
            <span className="text-teal-600 ml-1">
              *
            </span>
          )}

        </label>


        <span className="text-[10px] font-bold text-slate-300">
          {number}
        </span>

      </div>


      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => {
          onChange(event.target.value);
        }}
        className="professional-input"
      />

    </div>
  );
}


/* =========================================================
   ANIMATED SELECT
   ========================================================= */

function AnimatedSelect({
  number,
  label,
  value,
  options,
  required = false,
  onChange,
}) {
  return (
    <div className="field-enter">

      <div className="flex items-center justify-between mb-2">

        <label className="text-sm font-semibold text-slate-800">

          {label}

          {required && (
            <span className="text-teal-600 ml-1">
              *
            </span>
          )}

        </label>


        <span className="text-[10px] font-bold text-slate-300">
          {number}
        </span>

      </div>


      <select
        value={value}
        onChange={(event) => {
          onChange(event.target.value);
        }}
        className="professional-input appearance-none"
      >

        {options.map(([optionValue, optionLabel]) => (

          <option
            key={optionValue}
            value={optionValue}
          >
            {optionLabel}
          </option>

        ))}

      </select>

    </div>
  );
}


/* =========================================================
   CHOICE FIELD
   ========================================================= */

function ChoiceField({
  number,
  label,
  value,
  options,
  onChange,
}) {
  return (
    <div className="field-enter">


      <div className="flex items-center justify-between mb-3">

        <label className="text-sm font-semibold text-slate-800">
          {label}
        </label>


        <span className="text-[10px] font-bold text-slate-300">
          {number}
        </span>

      </div>


      <div className="grid grid-cols-3 gap-3">

        {options.map(([optionValue, optionLabel]) => (

          <button
            type="button"
            key={optionValue}
            onClick={() => onChange(optionValue)}
            className={`py-3 rounded-xl border font-semibold transition-all duration-300 ${
              value === optionValue
                ? "border-teal-500 bg-teal-50 text-teal-700 shadow-sm -translate-y-0.5"
                : "border-slate-200 bg-white text-slate-500 hover:border-slate-300 hover:bg-slate-50"
            }`}
          >

            {value === optionValue && (
              <span className="mr-1">
                ✓
              </span>
            )}

            {optionLabel}

          </button>

        ))}

      </div>

    </div>
  );
}


/* =========================================================
   PROGRESS BAR
   ========================================================= */

function ProgressBar({ active }) {

  const steps = [
    "Patient",
    "Eye",
    "Capture",
    "Quality",
    "Analysis",
    "Result",
  ];


  return (
    <div className="w-full">

      <div className="flex items-center">

        {steps.map((step, index) => {

          const isActive = index === active;

          const isCompleted = index < active;


          return (
            <div
              key={step}
              className="flex items-center flex-1 last:flex-none"
            >

              {/* STEP */}

              <div className="flex items-center gap-2 shrink-0">

                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-bold transition-all duration-500 ${
                    isCompleted
                      ? "bg-teal-500 text-white"
                      : isActive
                        ? "bg-teal-600 text-white shadow-lg shadow-teal-600/20"
                        : "bg-slate-100 text-slate-400"
                  }`}
                >

                  {isCompleted
                    ? "✓"
                    : index + 1}

                </div>


                <span
                  className={`hidden md:block text-xs font-semibold transition-colors duration-500 ${
                    isActive
                      ? "text-teal-700"
                      : isCompleted
                        ? "text-slate-600"
                        : "text-slate-400"
                  }`}
                >
                  {step}
                </span>

              </div>


              {/* CONNECTOR */}

              {index < steps.length - 1 && (

                <div className="flex-1 h-px bg-slate-200 mx-2 md:mx-4 relative overflow-hidden">

                  {isCompleted && (

                    <div className="absolute inset-y-0 left-0 w-full bg-teal-400 transition-all duration-700" />

                  )}

                </div>

              )}

            </div>
          );
        })}

      </div>

    </div>
  );
}


/* =========================================================
   PLACEHOLDER
   ========================================================= */

function Placeholder({
  step,
  title,
  description,
  onBack,
}) {
  return (
    <div className="min-h-screen bg-[#f4f8f8]">

      <header className="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between">

        <div>

          <h1 className="font-bold text-slate-900">
            RetinaSafe
          </h1>

          <p className="text-xs text-slate-500">
            Clinical Workspace
          </p>

        </div>


        <span className="text-sm text-slate-500">
          {step}
        </span>

      </header>


      <main className="min-h-[70vh] flex items-center justify-center px-6">

        <div className="text-center max-w-xl step-enter">

          <div className="w-20 h-20 mx-auto rounded-3xl bg-teal-50 border border-teal-100 flex items-center justify-center text-teal-700 text-3xl mb-7">
            ◉
          </div>


          <p className="text-xs uppercase tracking-[0.2em] text-teal-600 font-bold">
            Clinical review workspace
          </p>


          <h2 className="text-4xl font-bold text-slate-900 mt-3">
            {title}
          </h2>


          <p className="text-slate-500 mt-4 leading-relaxed">
            {description}
          </p>


          <button
            type="button"
            onClick={onBack}
            className="mt-8 px-6 py-3 bg-slate-950 text-white rounded-xl font-semibold hover:bg-teal-700 transition-all duration-300"
          >
            ← Back
          </button>

        </div>

      </main>

    </div>
  );
}


export default App;